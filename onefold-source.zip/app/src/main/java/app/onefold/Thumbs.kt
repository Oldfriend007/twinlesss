package app.onefold

import android.content.Context
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import java.util.concurrent.Executors

/** Loads small previews of photos and videos off the main thread, with a memory cache. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(48 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun cached(path: String): Bitmap? = cache.get(path)

    fun load(item: Item, sizePx: Int, target: ImageView, onLoaded: (() -> Unit)? = null) {
        val key = item.file.path
        target.tag = key
        val hit = cache.get(key)
        if (hit != null) { target.setImageBitmap(hit); onLoaded?.invoke(); return }
        target.setImageDrawable(null)
        if (item.category != Category.PHOTOS && item.category != Category.VIDEOS) return
        pool.execute {
            if (target.tag != key) return@execute
            val bmp = decode(item, sizePx)
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (target.tag == key) { target.setImageBitmap(bmp); onLoaded?.invoke() } }
            }
        }
    }

    fun decode(item: Item, sizePx: Int): Bitmap? = try {
        if (item.category == Category.VIDEOS) ThumbnailUtils.createVideoThumbnail(item.file, Size(sizePx, sizePx), null)
        else ThumbnailUtils.createImageThumbnail(item.file, Size(sizePx, sizePx), null)
    } catch (e: Exception) { null }
}

/** A frame that is always as tall as it is wide. */
class SquareFrame(context: Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
    }
}

fun View.dpx(v: Int): Int = (v * resources.displayMetrics.density).toInt()
