package app.onefold

import java.io.File
import java.io.IOException

/**
 * Remembers each file's fingerprint (by path, size and modified time) so rescans only read
 * files that are new or changed. "confirmed" means the file was byte-checked against a twin.
 */
class HashCache(private val file: File) {
    class Entry(val size: Long, val mtime: Long, val hash: String, var confirmed: Boolean)

    private val map = HashMap<String, Entry>()
    private val fresh = HashMap<String, Entry>()

    init {
        try {
            if (file.exists()) file.forEachLine { line ->
                val p = line.split('\t')
                if (p.size == 5) map[p[0]] = Entry(p[1].toLong(), p[2].toLong(), p[3], p[4] == "1")
            }
        } catch (e: Exception) { map.clear() }
    }

    fun get(path: String, size: Long, mtime: Long): Entry? {
        val e = map[path] ?: fresh[path] ?: return null
        return if (e.size == size && e.mtime == mtime) e else null
    }

    fun put(path: String, size: Long, mtime: Long, hash: String) { fresh[path] = Entry(size, mtime, hash, false) }

    fun markConfirmed(path: String) { (fresh[path] ?: map[path])?.confirmed = true }

    /** Keeps entries only for the given files (drops deleted or changed files). */
    fun keepOnly(items: List<Item>) {
        val next = HashMap<String, Entry>()
        for (i in items) {
            val h = i.hash ?: continue
            val old = map[i.file.path] ?: fresh[i.file.path]
            val confirmed = old != null && old.size == i.size && old.mtime == i.mtime && old.hash == h && old.confirmed
            next[i.file.path] = Entry(i.size, i.mtime, h, confirmed)
        }
        map.clear(); map.putAll(next); fresh.clear()
    }

    fun save() {
        try {
            val tmp = File(file.path + ".tmp")
            tmp.bufferedWriter().use { w ->
                for ((k, e) in map) if (!k.contains('\t') && !k.contains('\n')) w.write("$k\t${e.size}\t${e.mtime}\t${e.hash}\t${if (e.confirmed) 1 else 0}\n")
            }
            tmp.renameTo(file)
        } catch (e: Exception) { }
    }
}

class FreeResult(val moved: Int, val bytes: Long, val skipped: List<String>, val batch: File?)

class TrashBatch(val dir: File, val created: Long, val files: Int, val bytes: Long)

/**
 * Twinless Trash: originals are moved (renamed, never copied) into a hidden folder on the same
 * storage, so they can be put back exactly where they were. Space comes back when it's emptied;
 * batches older than 30 days are emptied automatically.
 */
object Trash {
    const val DAYS = 30
    private const val MANIFEST = "manifest.tsv"

    fun root(phoneRoot: File) = File(phoneRoot, ".Twinless Trash")

    fun batches(phoneRoot: File): List<TrashBatch> =
        (root(phoneRoot).listFiles() ?: emptyArray()).filter { File(it, MANIFEST).exists() }.map { d ->
            val lines = try { File(d, MANIFEST).readLines().filter { it.contains('\t') } } catch (e: Exception) { emptyList() }
            val bytes = lines.sumOf { File(it.substringAfter('\t')).let { f -> if (f.exists()) f.length() else 0L } }
            TrashBatch(d, d.name.toLongOrNull() ?: d.lastModified(), lines.size, bytes)
        }.sortedByDescending { it.created }

    /** Checks every original byte by byte against its library copy, then moves it to the trash. */
    fun freeUp(phoneRoot: File, scan: ScanResult, status: LibraryStatus, isCancelled: () -> Boolean, progress: Progress): FreeResult {
        val groupOf = HashMap<Item, List<Item>>()
        scan.groups.forEach { g -> groupOf[g.keep] = listOf(g.keep) + g.extras }
        val jobs = ArrayList<Pair<Item, File>>()
        for ((item, libFile) in status.matched) {
            for (copy in groupOf[item] ?: listOf(item)) jobs.add(copy to libFile)
        }
        val total = jobs.sumOf { it.first.size }
        val stamp = System.currentTimeMillis()
        val batch = File(root(phoneRoot), stamp.toString())
        val manifest = File(batch, MANIFEST)
        var moved = 0
        var bytes = 0L
        var done = 0L
        val skipped = ArrayList<String>()
        val rootPath = phoneRoot.canonicalPath
        for ((copy, libFile) in jobs) {
            if (isCancelled()) break
            progress.update("Checking originals", done, total, true, copy.file.name)
            val f = copy.file
            try {
                val unchanged = f.exists() && f.length() == copy.size && f.lastModified() == copy.mtime
                if (!unchanged || !libFile.exists() || !Engine.sameBytes(f, libFile)) {
                    skipped.add("${f.path} (doesn't match its library copy, left in place)")
                    done += copy.size
                    continue
                }
                progress.update("Moving to trash", done, total, true, f.name)
                if (!batch.exists()) {
                    batch.mkdirs()
                    File(root(phoneRoot), ".nomedia").createNewFile()
                }
                val rel = f.canonicalPath.removePrefix(rootPath).trimStart('/')
                val dest = File(batch, "files/$rel")
                dest.parentFile?.mkdirs()
                if (f.renameTo(dest)) {
                    manifest.appendText("${f.path}\t${dest.path}\n")
                    moved++; bytes += copy.size
                } else skipped.add("${f.path} (couldn't be moved)")
            } catch (e: IOException) {
                skipped.add("${f.path} (${e.message})")
            }
            done += copy.size
        }
        progress.update("Moving to trash", total, total, true, "")
        return FreeResult(moved, bytes, skipped, if (moved > 0) batch else null)
    }

    /** Puts every file of a batch back where it was. Returns how many were restored. */
    fun restore(batch: File): Int {
        val manifest = File(batch, MANIFEST)
        var n = 0
        val left = ArrayList<String>()
        for (line in manifest.readLines()) {
            val orig = File(line.substringBefore('\t'))
            val now = File(line.substringAfter('\t'))
            if (!now.exists()) continue
            orig.parentFile?.mkdirs()
            if (!orig.exists() && now.renameTo(orig)) n++ else left.add(line)
        }
        if (left.isEmpty()) batch.deleteRecursively() else manifest.writeText(left.joinToString("\n", postfix = "\n"))
        return n
    }

    fun empty(batch: File): Long {
        val bytes = try {
            File(batch, MANIFEST).readLines().filter { it.contains('\t') }.sumOf { File(it.substringAfter('\t')).let { f -> if (f.exists()) f.length() else 0L } }
        } catch (e: Exception) { 0L }
        batch.deleteRecursively()
        return bytes
    }

    /** Empties batches older than 30 days. */
    fun expire(phoneRoot: File) {
        val cutoff = System.currentTimeMillis() - DAYS * 24L * 3600 * 1000
        batches(phoneRoot).filter { it.created < cutoff }.forEach { it.dir.deleteRecursively() }
    }

    fun originals(batch: File): List<String> =
        try { File(batch, MANIFEST).readLines().filter { it.contains('\t') }.map { it.substringBefore('\t') } } catch (e: Exception) { emptyList() }
}
