package app.onefold

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random
import android.graphics.Typeface
import android.content.res.AssetManager

object Palette {
    val bg = Color.parseColor("#0A0713")
    val surface = Color.argb(20, 255, 255, 255)      // glass on the glow
    val surface2 = Color.argb(34, 255, 255, 255)
    val stroke = Color.argb(26, 255, 255, 255)
    val ink = Color.parseColor("#F7F4FF")
    val inkDim = Color.parseColor("#A9A1C6")
    val line = Color.argb(60, 255, 255, 255)
    val cobalt = Color.parseColor("#5B21B6")       // deep violet
    val electric = Color.parseColor("#8B5CF6")     // violet, the action colour
    val violet = Color.parseColor("#EC4899")       // magenta, second stop of the gradient
    val peach = Color.parseColor("#FDBA74")
    val sunflower = Color.parseColor("#FBBF24")
    val mint = Color.parseColor("#34D399")

    fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
}

/** Slowly drifting brand glow with film grain, fading out down the screen. */
class GlowView(context: Context, private val animated: Boolean) : View(context) {
    private val start = SystemClock.uptimeMillis()
    private val blob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grainPaint = Paint().apply {
        shader = BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private var band = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        band = min(h.toFloat(), 480 * resources.displayMetrics.density)
        maskPaint.shader = LinearGradient(0f, 0f, 0f, band,
            intArrayOf(Color.BLACK, Color.argb(110, 0, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        canvas.drawColor(Palette.bg)
        if (band <= 0f) return
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val layer = canvas.saveLayer(0f, 0f, w, band, null)

        val x1 = w * (0.22f + 0.14f * sin(t * 0.23f))
        blob.shader = RadialGradient(x1, band * 0.12f, w * 0.95f,
            Palette.withAlpha(Palette.electric, 170), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, band, blob)

        val x2 = w * (0.82f + 0.12f * cos(t * 0.19f))
        blob.shader = RadialGradient(x2, band * 0.02f, w * 0.8f,
            Palette.withAlpha(Palette.violet, 120), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, band, blob)

        canvas.drawRect(0f, 0f, w, band, grainPaint)
        canvas.drawRect(0f, 0f, w, band, maskPaint)
        canvas.restoreToCount(layer)
        if (animated) postInvalidateDelayed(40)
    }

    companion object {
        /** Grain with both light and dark specks so it reads on any colour. */
        val noise: Bitmap by lazy {
            val size = 160
            val px = IntArray(size * size)
            val rnd = Random(7)
            for (i in px.indices) {
                val r = rnd.nextFloat()
                px[i] = when {
                    r < 0.10f -> Color.argb(34, 255, 255, 255)
                    r < 0.20f -> Color.argb(46, 0, 0, 0)
                    else -> Color.TRANSPARENT
                }
            }
            Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        }
    }
}

/** Rows of the person's own photos drifting sideways, used behind the results headline. */
class MosaicView(context: Context, private val animated: Boolean) : View(context) {
    private val tiles = ArrayList<Bitmap>()
    private val start = SystemClock.uptimeMillis()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint()
    private val dst = RectF()
    private val src = Rect()
    private var fade = 0f

    fun setPhotos(list: List<Bitmap>) {
        tiles.clear()
        tiles.addAll(list)
        fade = 0f
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        shade.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.argb(110, 9, 8, 15), Color.argb(235, 9, 8, 15)),
            null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        if (tiles.isEmpty()) return
        val d = resources.displayMetrics.density
        val rows = 3
        val gap = 6 * d
        val tile = (height - gap * (rows - 1)) / rows
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        fade = min(1f, fade + 0.04f)
        paint.alpha = (fade * 255).toInt()
        val perRow = maxOf(4, (width / (tile + gap)).toInt() + 2)
        val period = perRow * (tile + gap)
        for (r in 0 until rows) {
            val speed = (if (r % 2 == 0) 1 else -1) * (10f + 5f * r) * d
            var offset = (t * speed) % period
            if (offset < 0) offset += period
            val y = r * (tile + gap)
            var i = 0
            var x = offset - period
            while (x < width) {
                val bmp = tiles[(r * 5 + i) % tiles.size]
                src.set(0, 0, bmp.width, bmp.height)
                dst.set(x, y, x + tile, y + tile)
                canvas.drawBitmap(bmp, src, dst, paint)
                x += tile + gap
                i = (i + 1) % perRow
            }
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), shade)
        if (animated || fade < 1f) postInvalidateDelayed(40)
    }

    companion object {
        fun rounded(src: Bitmap, size: Int, radius: Float): Bitmap {
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val side = min(src.width, src.height)
            val sx = (src.width - side) / 2
            val sy = (src.height - side) / 2
            val path = Path().apply { addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), radius, radius, Path.Direction.CW) }
            c.clipPath(path)
            c.drawBitmap(src, Rect(sx, sy, sx + side, sy + side), Rect(0, 0, size, size), p)
            return out
        }
    }
}

/** The logo, alive: a twin drifts into the original and disappears. */
class TwinMarkView(context: Context, private val animated: Boolean) : View(context) {
    private val start = SystemClock.uptimeMillis()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private fun smooth(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3 - 2 * c) }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val rad = s * 0.22f
        val t = if (animated) ((SystemClock.uptimeMillis() - start) / 1000f) % 3.6f else 3f
        // 0–1.2s: twin sits apart; 1.2–2.4s: it slides in and fades; 2.4–3.6s: it reappears
        val merge = smooth((t - 1.2f) / 1.2f)
        val back = smooth((t - 2.6f) / 0.9f)
        val apart = (1f - merge) + back
        val twinAlpha = ((1f - merge) * 0.42f + back * 0.42f).coerceIn(0f, 0.42f)
        val offset = rad * 0.95f * apart.coerceIn(0f, 1f)

        glow.shader = RadialGradient(cx + rad * 0.35f, cy, rad * 2.6f,
            Palette.withAlpha(Palette.electric, 120), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx + rad * 0.35f, cy, rad * 2.6f, glow)

        // the twin
        p.shader = null
        p.color = Color.WHITE
        p.alpha = (twinAlpha * 255).toInt()
        canvas.drawCircle(cx + rad * 0.35f - offset, cy, rad, p)

        // the one that stays
        p.alpha = 255
        p.shader = LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad,
            Color.WHITE, Color.parseColor("#E9E2FF"), Shader.TileMode.CLAMP)
        val ox = cx + rad * 0.35f
        canvas.drawCircle(ox, cy, rad, p)

        // sparkle
        val k = rad * 0.42f * (1f + 0.08f * sin(t * 3f))
        path.reset()
        path.moveTo(ox, cy - k)
        path.quadTo(ox + k * 0.14f, cy - k * 0.14f, ox + k, cy)
        path.quadTo(ox + k * 0.14f, cy + k * 0.14f, ox, cy + k)
        path.quadTo(ox - k * 0.14f, cy + k * 0.14f, ox - k, cy)
        path.quadTo(ox - k * 0.14f, cy - k * 0.14f, ox, cy - k)
        path.close()
        p.shader = LinearGradient(ox - k, cy - k, ox + k, cy + k, Palette.electric, Palette.violet, Shader.TileMode.CLAMP)
        canvas.drawPath(path, p)

        if (animated) postInvalidateDelayed(30)
    }
}

/** Files streaming through a scanning beam; duplicates flash and fold away. */
class ScanView(context: Context, private val animated: Boolean) : View(context) {
    private class Card(var x: Float, var lane: Int, var speed: Float, var type: Int, var dup: Boolean, var scanned: Float = -1f)

    private val types = listOf(
        "JPG" to Color.parseColor("#8B6CFF"), "MP4" to Color.parseColor("#FF5FA2"), "PDF" to Color.parseColor("#FF7A6B"),
        "PNG" to Color.parseColor("#8B6CFF"), "MP3" to Color.parseColor("#3DDC97"), "ZIP" to Color.parseColor("#FFC845"),
        "APK" to Color.parseColor("#62D2FF"), "HEIC" to Color.parseColor("#B49CFF")
    )
    private val rnd = Random(11)
    private val cards = ArrayList<Card>()
    private val d = resources.displayMetrics.density
    private val cardW = 46 * d
    private val cardH = 58 * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9.5f * d
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val r = RectF()
    private var last = SystemClock.uptimeMillis()
    private val start = last

    /** Speeds the stream up while work is happening. */
    var busy: Boolean = true

    private fun spawn(x: Float) = Card(x, rnd.nextInt(3), (34 + rnd.nextInt(30)) * d, rnd.nextInt(types.size), rnd.nextFloat() < 0.28f)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cards.clear()
        var x = -cardW
        while (x < w + cardW * 2) { cards.add(spawn(x)); x += cardW * (0.9f + rnd.nextFloat()) }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        val dt = if (animated) ((now - last) / 1000f).coerceAtMost(0.05f) else 0f
        last = now
        val t = (now - start) / 1000f
        val beamX = w * 0.5f

        // dot grid
        p.shader = null
        val gap = 18 * d
        var gy = gap / 2
        while (gy < h) {
            var gx = gap / 2
            while (gx < w) {
                val fadeX = 1f - (kotlin.math.abs(gx - beamX) / (w / 2)).coerceIn(0f, 1f)
                p.color = Palette.withAlpha(Palette.electric, (18 + 50 * fadeX * fadeX).toInt())
                canvas.drawCircle(gx, gy, 1.1f * d, p)
                gx += gap
            }
            gy += gap
        }

        // beam glow
        p.shader = LinearGradient(beamX - 70 * d, 0f, beamX + 70 * d, 0f,
            intArrayOf(Color.TRANSPARENT, Palette.withAlpha(Palette.electric, 60), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(beamX - 70 * d, 0f, beamX + 70 * d, h, p)

        val lanes = floatArrayOf(h * 0.2f, h * 0.5f, h * 0.8f)
        val speedUp = if (busy) 1f else 0.35f
        for (c in cards) {
            c.x -= c.speed * dt * speedUp
            val cy = lanes[c.lane] + sin(t * 1.4f + c.lane + c.x / 90f) * 4 * d
            val left = c.x
            if (c.scanned < 0 && left + cardW / 2 <= beamX) c.scanned = t
            val since = if (c.scanned < 0) -1f else t - c.scanned

            var alpha = 1f
            var scale = 1f
            if (c.dup && since >= 0) {
                val f = (since / 0.6f).coerceIn(0f, 1f)
                alpha = 1f - f
                scale = 1f - 0.35f * f
            }
            val edge = (minOf(left + cardW, w - left) / (60 * d)).coerceIn(0f, 1f)
            alpha *= edge
            if (alpha <= 0.01f) continue

            val cw = cardW * scale
            val ch = cardH * scale
            val cx = left + cardW / 2
            r.set(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
            val (label, color) = types[c.type]

            p.shader = null
            p.color = Palette.surface2
            p.alpha = (alpha * 255).toInt()
            canvas.drawRoundRect(r, 9 * d, 9 * d, p)

            // a thumbnail-like tinted top
            val top = RectF(r.left + 5 * d, r.top + 5 * d, r.right - 5 * d, r.top + ch * 0.55f)
            p.shader = LinearGradient(top.left, top.top, top.right, top.bottom,
                Palette.withAlpha(color, 210), Palette.withAlpha(color, 90), Shader.TileMode.CLAMP)
            p.alpha = (alpha * 255).toInt()
            canvas.drawRoundRect(top, 6 * d, 6 * d, p)
            p.shader = null
            text.color = Color.WHITE
            text.alpha = (alpha * 255).toInt()
            canvas.drawText(label, top.centerX(), top.centerY() + 3.5f * d, text)

            p.color = Palette.line
            p.alpha = (alpha * 255).toInt()
            canvas.drawRoundRect(RectF(r.left + 6 * d, r.bottom - ch * 0.3f, r.right - 10 * d, r.bottom - ch * 0.3f + 3.5f * d), 2 * d, 2 * d, p)
            canvas.drawRoundRect(RectF(r.left + 6 * d, r.bottom - ch * 0.17f, r.right - 18 * d, r.bottom - ch * 0.17f + 3.5f * d), 2 * d, 2 * d, p)

            // outline once scanned: mint = kept, yellow = duplicate
            if (since >= 0) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * d
                p.color = if (c.dup) Palette.sunflower else Palette.mint
                p.alpha = (alpha * 255 * (if (c.dup) 1f else (1f - since / 2.5f).coerceIn(0.25f, 1f))).toInt()
                canvas.drawRoundRect(r, 9 * d, 9 * d, p)
                p.style = Paint.Style.FILL
            }
        }

        // recycle cards that left the screen
        for (i in cards.indices) {
            val c = cards[i]
            if (c.x + cardW < 0 || (c.dup && c.scanned >= 0 && t - c.scanned > 0.7f)) {
                val rightmost = cards.maxOf { it.x }
                cards[i] = spawn(maxOf(w + cardW * 0.3f, rightmost + cardW * (0.9f + rnd.nextFloat())))
            }
        }

        // the beam
        p.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.TRANSPARENT, Palette.electric, Palette.violet, Color.TRANSPARENT), floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        p.alpha = (200 + 55 * sin(t * 4f)).toInt().coerceIn(0, 255)
        canvas.drawRect(beamX - 1.2f * d, 0f, beamX + 1.2f * d, h, p)
        p.shader = null

        if (animated) postInvalidateOnAnimation()
    }
}

/** Motion curves tuned to feel like iOS: quick start, long soft landing. */
object Curves {
    /** iOS-style ease used for pushes and sheets. */
    val ios = android.view.animation.PathInterpolator(0.32f, 0.72f, 0f, 1f)
    /** A critically damped spring: settles with no wobble. */
    val spring = android.view.animation.Interpolator { t ->
        val x = t.toDouble()
        (1.0 - Math.exp(-7.0 * x) * (1.0 + 7.0 * x)).toFloat().coerceIn(0f, 1f)
    }
    /** A light spring with a tiny overshoot, for things that pop in. */
    val pop = android.view.animation.Interpolator { t ->
        val x = t.toDouble()
        (1.0 - Math.exp(-6.0 * x) * Math.cos(9.0 * x)).toFloat()
    }
}

/** Gradient progress bar that glides to each new value, with a moving sheen and a glowing tip. */
class ProgressLine(context: Context, private val animated: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val clip = Path()
    private val start = SystemClock.uptimeMillis()
    private var last = start
    private var shown = 0f
    private val d = resources.displayMetrics.density

    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); if (!animated) shown = field; invalidate() }
    var indeterminate = true
        set(v) { field = v; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        val dt = ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        val t = (now - start) / 1000f
        val pad = 4 * d                // room for the glow
        val bh = h - pad * 2
        val rad = bh / 2

        p.shader = null
        p.color = Palette.surface2
        r.set(0f, pad, w, pad + bh)
        canvas.drawRoundRect(r, rad, rad, p)

        if (indeterminate) {
            // two soft comets chasing each other
            for (k in 0..1) {
                val phase = ((t / 1.6f) + k * 0.5f) % 1f
                val eased = Curves.ios.getInterpolation(phase)
                val len = w * (0.18f + 0.22f * kotlin.math.sin(phase * Math.PI.toFloat()))
                val x = -len + eased * (w + len)
                r.set(x, pad, x + len, pad + bh)
                p.shader = LinearGradient(r.left, 0f, r.right, 0f,
                    intArrayOf(Color.TRANSPARENT, Palette.electric, Palette.violet), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
                p.alpha = if (k == 0) 255 else 140
                canvas.drawRoundRect(r, rad, rad, p)
            }
            p.alpha = 255
            if (animated) postInvalidateOnAnimation()
            return
        }

        // glide toward the real value
        shown += (progress - shown) * (1f - Math.exp(-dt * 7.0).toFloat())
        if (kotlin.math.abs(progress - shown) < 0.0005f) shown = progress
        val fw = maxOf(bh, w * shown)

        clip.reset()
        clip.addRoundRect(RectF(0f, pad, fw, pad + bh), rad, rad, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        // gradient that slowly flows along the bar
        val flow = (t * 60 * d) % (w * 2)
        p.shader = LinearGradient(-flow, 0f, w * 2 - flow, 0f,
            intArrayOf(Palette.electric, Palette.violet, Palette.peach, Palette.violet, Palette.electric), null, Shader.TileMode.MIRROR)
        canvas.drawRect(0f, pad, fw, pad + bh, p)
        // sheen sweeping across the filled part
        val sx = ((t % 1.8f) / 1.8f) * (fw + 80 * d) - 40 * d
        p.shader = LinearGradient(sx - 30 * d, 0f, sx + 30 * d, 0f,
            intArrayOf(Color.TRANSPARENT, Color.argb(110, 255, 255, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, pad, fw, pad + bh, p)
        canvas.restore()

        // glowing tip
        if (shown in 0.005f..0.995f) {
            val pulse = 1f + 0.18f * kotlin.math.sin(t * 5f)
            val gx = fw - rad
            val gy = pad + rad
            p.shader = RadialGradient(gx, gy, bh * 1.6f * pulse,
                Palette.withAlpha(Color.WHITE, 170), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            canvas.drawCircle(gx, gy, bh * 1.6f * pulse, p)
        }
        p.shader = null
        if (animated) postInvalidateOnAnimation()
    }
}

/** Outfit (SIL Open Font License), a variable font bundled in assets/fonts, for display text. */
object Fonts {
    private val cache = HashMap<Int, android.graphics.Typeface>()
    fun display(assets: android.content.res.AssetManager, weight: Int): android.graphics.Typeface = cache.getOrPut(weight) {
        try {
            android.graphics.Typeface.Builder(assets, "fonts/Outfit.ttf")
                .setFontVariationSettings("'wght' $weight")
                .setFallback("sans-serif")
                .build()
        } catch (e: Exception) {
            android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
    }
}
