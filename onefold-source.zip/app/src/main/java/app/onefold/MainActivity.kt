package app.onefold

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import android.text.InputType
import android.text.format.Formatter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class MainActivity : Activity() {

    private enum class Screen { PERMISSION, START, PROGRESS, RESULTS, REVIEW, FOLDER, DONE }
    private enum class Motion { FADE, FORWARD, BACK, RISE }

    private val bg = Palette.bg
    private val surface = Palette.surface
    private val surface2 = Palette.surface2
    private val ink = Palette.ink
    private val inkDim = Palette.inkDim
    private val electric = Palette.electric
    private val violet = Palette.violet
    private val sunflower = Palette.sunflower
    private val mint = Palette.mint

    private val phoneRoot: File = Environment.getExternalStorageDirectory()
    private var screen = Screen.START

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private var motionOn = true

    private var ring: ProgressLine? = null
    private var scan: ScanView? = null
    private var bigNumber: TextView? = null
    private var bigLabel: TextView? = null
    private var phaseText: TextView? = null
    private var detailText: TextView? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int): Float = v * resources.displayMetrics.density
    private fun fmt(bytes: Long): String = Formatter.formatFileSize(this, bytes)
    private fun num(n: Int): String = String.format(Locale.US, "%,d", n)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        motionOn = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
        root = FrameLayout(this)
        root.addView(GlowView(this, motionOn), FrameLayout.LayoutParams(-1, -1))
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))
        stage.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(root)
        live = this
        appCtx = applicationContext
        val waiting = pending
        pending = null
        when {
            waiting != null -> waiting()
            busy -> showProgressScreen(lastPhase)
            else -> showStart(Motion.FADE)
        }
    }

    override fun onDestroy() {
        if (live === this) live = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val waiting = pending
        pending = null
        waiting?.invoke(this)
    }

    private fun askForNotifications() {
        if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    override fun onResume() {
        super.onResume()
        if (screen == Screen.PERMISSION || (screen == Screen.START && !Environment.isExternalStorageManager())) showStart(Motion.FADE)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.PROGRESS -> moveTaskToBack(true)
            Screen.FOLDER -> showReview(Motion.BACK)
            Screen.REVIEW -> scanResult?.let { showResults(it, Motion.BACK) }
            Screen.RESULTS, Screen.DONE -> { scanResult = null; libraryStatus = null; showStart(Motion.BACK) }
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ---------- Building blocks ----------

    /** Shows a screen: scrolling content plus an optional bar pinned at the bottom. */
    private fun setScreen(s: Screen, content: View, bar: View?, motion: Motion, scroll: Boolean = true) {
        screen = s
        val page = FrameLayout(this)
        if (scroll) {
            page.addView(ScrollView(this).apply {
                isFillViewport = true
                isVerticalScrollBarEnabled = false
                addView(content)
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            page.addView(content, FrameLayout.LayoutParams(-1, -1))
        }
        if (bar != null) {
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            holder.addView(View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, bg))
            }, LinearLayout.LayoutParams(-1, dp(28)))
            holder.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(bg)
                setPadding(dp(20), 0, dp(20), dp(12))
                addView(bar)
            })
            page.addView(holder, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            if (scroll) holder.post { content.setPadding(content.paddingLeft, content.paddingTop, content.paddingRight, holder.height + dp(8)) }
        }
        val old = if (stage.childCount > 0) stage.getChildAt(stage.childCount - 1) else null
        stage.addView(page, FrameLayout.LayoutParams(-1, -1))
        if (!motionOn || old == null) {
            if (old != null) stage.removeView(old)
            return
        }
        val w = stage.width.toFloat().coerceAtLeast(dpf(360))
        when (motion) {
            Motion.FORWARD -> { page.translationX = w * 0.28f; page.alpha = 0f }
            Motion.BACK -> { page.translationX = -w * 0.22f; page.alpha = 0f }
            Motion.RISE -> { page.translationY = dpf(56); page.scaleX = 0.97f; page.scaleY = 0.97f; page.alpha = 0f }
            Motion.FADE -> { page.alpha = 0f; page.scaleX = 1.02f; page.scaleY = 1.02f }
        }
        page.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(460).setInterpolator(Curves.ios).start()
        old.animate().alpha(0f)
            .translationX(when (motion) { Motion.FORWARD -> -w * 0.12f; Motion.BACK -> w * 0.16f; else -> 0f })
            .scaleX(if (motion == Motion.RISE) 0.96f else 1f).scaleY(if (motion == Motion.RISE) 0.96f else 1f)
            .setDuration(240).setInterpolator(Curves.ios).withEndAction { stage.removeView(old) }.start()
        stagger(content)
    }

    /** Children arrive one after another, like an iOS list settling in. */
    private fun stagger(content: View) {
        val col = content as? LinearLayout ?: return
        val n = minOf(col.childCount, 9)
        for (i in 0 until n) {
            val c = col.getChildAt(i)
            c.alpha = 0f
            c.translationY = dpf(18)
            c.animate().alpha(1f).translationY(0f).setStartDelay(60L + i * 40L).setDuration(520).setInterpolator(Curves.ios).start()
        }
    }

    private fun column(gravity: Int = Gravity.START): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        this.gravity = gravity
        setPadding(dp(20), dp(16), dp(20), dp(24))
    }

    private fun label(s: String, size: Float, color: Int = ink, weight: Int = 400, top: Int = 0, center: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            typeface = when {
                weight >= 800 -> Fonts.display(assets, 750)
                weight >= 700 -> Fonts.display(assets, 650)
                weight >= 500 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
                else -> Typeface.create("sans-serif", Typeface.NORMAL)
            }
            setPadding(0, dp(top), 0, 0)
            setLineSpacing(0f, if (weight >= 800) 1.05f else 1.25f)
            if (weight >= 800) letterSpacing = -0.02f
            if (center) gravity = Gravity.CENTER_HORIZONTAL
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { cornerRadius = dpf(radius); setColor(color) }

    /** Frosted glass surface: lets the glow through, with a hairline edge. */
    private fun glass(radius: Int, tint: Int = surface): GradientDrawable =
        GradientDrawable().apply { cornerRadius = dpf(radius); setColor(tint); setStroke(dp(1), Palette.stroke) }

    private val accentText = Color.parseColor("#C4B1FF")

    private fun press(v: View, action: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener {
            if (motionOn) v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).setInterpolator(Curves.ios).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(Curves.pop).start()
            }.start()
            action()
        }
    }

    private fun primary(text: String, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTextColor(Color.WHITE)
        typeface = Fonts.display(assets, 600)
        gravity = Gravity.CENTER
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(electric, violet, Palette.peach)).apply {
            cornerRadius = dpf(26)
            setGradientCenter(0.6f, 0.5f)
        }
        elevation = dpf(10)
        outlineSpotShadowColor = violet
        outlineAmbientShadowColor = electric
        layoutParams = LinearLayout.LayoutParams(-1, dp(52))
        press(this, action)
    }

    private fun textButton(text: String, color: Int = inkDim, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        minHeight = dp(44)
        setPadding(dp(12), 0, dp(12), 0)
        press(this, action)
    }

    private fun card(parent: LinearLayout, color: Int = surface, top: Int = 12): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = glass(18, color)
        }
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        return c
    }

    private fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** 0 = off, 1 = on, 2 = partly on. */
    private fun checkBox(state: Int): TextView = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(Color.WHITE)
        text = when (state) { 1 -> "✓"; 2 -> "–"; else -> "" }
        background = GradientDrawable().apply {
            cornerRadius = dpf(7)
            if (state == 0) { setColor(Color.TRANSPARENT); setStroke(dp(2), Palette.line) }
            else setColor(if (state == 1) electric else Palette.withAlpha(electric, 140))
        }
        layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = dp(12) }
    }

    // ---------- Start ----------

    private fun showStart(motion: Motion) {
        if (!Environment.isExternalStorageManager()) { showPermission(); return }
        val col = column()
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(electric, violet)).apply { shape = GradientDrawable.OVAL }
        }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) })
        brand.addView(label("Twinless", 17f, ink, 700))
        col.addView(brand)
        col.addView(TwinMarkView(this, motionOn), LinearLayout.LayoutParams(-1, dp(260)).apply { topMargin = dp(8) })
        col.addView(label("Your phone,\nwithout the copies.", 36f, ink, 800, top = 4).apply { setLineSpacing(0f, 1.05f) })
        col.addView(label("Finds exact duplicate photos, videos and files. Keeps one of each.", 16f, inkDim, top = 12))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (t in listOf("Byte-exact", "On-device", "Nothing deleted")) {
            chips.addView(label(t, 12f, ink, 500).apply {
                background = rounded(Palette.withAlpha(Color.WHITE, 18), 14)
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        col.addView(chips, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })

        val extras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(extras, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val weekly = card(extras, top = 12)
        val wRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val wTxt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wTxt.addView(label("Weekly check", 16f, ink, 700))
        wTxt.addView(label("Scans while charging and tells you when new duplicates pile up.", 13f, inkDim, top = 2))
        wRow.addView(wTxt, LinearLayout.LayoutParams(0, -2, 1f))
        wRow.addView(android.widget.Switch(this).apply {
            isChecked = WeeklyJob.isOn(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                WeeklyJob.set(this@MainActivity, on)
                if (on) askForNotifications()
            }
        })
        weekly.addView(wRow)
        loadTrashCard(extras)

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bar.addView(primary("Scan my phone") { startScan() })
        bar.addView(label("App data and WhatsApp backups are never touched.", 12f, inkDim, top = 10, center = true))
        setScreen(Screen.START, col, bar, motion)
    }

    private fun showPermission() {
        val col = column()
        col.addView(TwinMarkView(this, motionOn), LinearLayout.LayoutParams(-1, dp(240)).apply { topMargin = dp(24) })
        col.addView(label("One permission", 36f, ink, 800, top = 12))
        col.addView(label("Twinless needs “All files access” to see every folder. Everything stays on your phone.", 16f, inkDim, top = 10))
        val bar = primary("Allow file access") {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        }
        setScreen(Screen.PERMISSION, col, bar, Motion.FADE)
    }

    // ---------- Progress ----------

    private enum class Stage { SCAN, MATCH, CONFIRM, COPY, TRASH }

    private val jobSteps = mapOf(
        "scan" to listOf("Find files", "Find duplicates", "Confirm", "Check library"),
        "copy" to listOf("Check space", "Copy and verify", "Counter-check"),
        "verify" to listOf("Verify every file"),
        "free" to listOf("Check originals", "Move to trash")
    )
    private fun stepOf(phase: String): Int = when (phase) {
        "Looking for files", "Checking space", "Verifying byte by byte", "Checking originals" -> 0
        "Checking for duplicates", "Copying and verifying", "Moving to trash" -> 1
        "Confirming duplicates" -> 2
        "Checking your library" -> if (currentJob == "copy") 2 else 3
        else -> -1
    }
    private fun stageOf(phase: String): Stage = when (phase) {
        "Checking for duplicates" -> Stage.MATCH
        "Confirming duplicates", "Checking your library", "Verifying byte by byte", "Checking originals" -> Stage.CONFIRM
        "Copying and verifying", "Checking space" -> Stage.COPY
        "Moving to trash" -> Stage.TRASH
        else -> Stage.SCAN
    }

    private var stageViews: Map<Stage, View> = emptyMap()
    private var shownStage: Stage? = null
    private var stepper: LinearLayout? = null
    private var statsText: TextView? = null
    private var jobStart = 0L
    private var speedSample = Pair(0L, 0L)
    private var speed = 0.0

    private fun showProgressScreen(title: String) {
        val col = column()
        val steps = jobSteps[currentJob] ?: listOf(title)
        val st = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        col.addView(st, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        stepper = st
        renderSteps(steps, stepOf(title))

        phaseText = label(title, 26f, ink, 800, top = 18)
        col.addView(phaseText)
        detailText = label("", 13f, inkDim, top = 4).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
        col.addView(detailText, LinearLayout.LayoutParams(-1, -2))

        val stageBox = FrameLayout(this)
        val views = mapOf(
            Stage.SCAN to ScanView(this, motionOn),
            Stage.MATCH to MatchView(this, motionOn),
            Stage.CONFIRM to ConfirmView(this, motionOn),
            Stage.COPY to CopyView(this, motionOn, false),
            Stage.TRASH to CopyView(this, motionOn, true)
        )
        val first = stageOf(title)
        for ((k, v) in views) {
            v.alpha = if (k == first) 1f else 0f
            v.visibility = if (k == first) View.VISIBLE else View.INVISIBLE
            stageBox.addView(v, FrameLayout.LayoutParams(-1, -1))
        }
        stageViews = views
        shownStage = first
        col.addView(stageBox, LinearLayout.LayoutParams(-1, dp(270)).apply { topMargin = dp(14); leftMargin = -dp(20); rightMargin = -dp(20) })

        val numRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        bigNumber = label("0", 54f, ink, 800).apply { fontFeatureSettings = "tnum" }
        numRow.addView(bigNumber)
        bigLabel = label("", 15f, inkDim).apply { setPadding(dp(10), 0, 0, dp(12)) }
        numRow.addView(bigLabel, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(numRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val line = ProgressLine(this, motionOn)
        col.addView(line, LinearLayout.LayoutParams(-1, dp(18)).apply { topMargin = dp(6) })
        ring = line
        statsText = label("", 13f, inkDim, 500, top = 8).apply { fontFeatureSettings = "tnum" }
        col.addView(statsText)
        jobStart = SystemClock.uptimeMillis()
        speedSample = Pair(jobStart, 0L)
        speed = 0.0

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bar.addView(label("You can leave the app. Progress shows in your notifications.", 12f, inkDim, center = true))
        bar.addView(textButton("Cancel") { cancelRequested = true; detailText?.text = "Stopping safely…" })
        setScreen(Screen.PROGRESS, col, bar, Motion.RISE)
    }

    private fun renderSteps(steps: List<String>, current: Int) {
        val st = stepper ?: return
        st.removeAllViews()
        steps.forEachIndexed { i, name ->
            val done = i < current
            val now = i == current
            val dot = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 11f
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                text = if (done) "✓" else "${i + 1}"
                setTextColor(if (done || now) Color.WHITE else inkDim)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    when {
                        done -> setColor(Palette.withAlpha(mint, 200))
                        now -> setColor(electric)
                        else -> { setColor(Color.TRANSPARENT); setStroke(dp(1), Palette.line) }
                    }
                }
            }
            st.addView(dot, LinearLayout.LayoutParams(dp(20), dp(20)))
            if (now || steps.size <= 2) st.addView(label(name, 12f, if (now) ink else inkDim, 500).apply { setPadding(dp(6), 0, 0, 0) })
            if (i < steps.size - 1) st.addView(View(this).apply { setBackgroundColor(if (done) Palette.withAlpha(mint, 150) else Palette.line) },
                LinearLayout.LayoutParams(0, dp(2), 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
    }

    private fun switchStage(to: Stage) {
        if (shownStage == to) return
        val old = shownStage?.let { stageViews[it] }
        val nv = stageViews[to] ?: return
        shownStage = to
        nv.visibility = View.VISIBLE
        nv.scaleX = 0.94f; nv.scaleY = 0.94f
        nv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(if (motionOn) 480 else 0).setInterpolator(Curves.ios).start()
        old?.animate()?.alpha(0f)?.setDuration(if (motionOn) 260 else 0)?.withEndAction { old.visibility = View.INVISIBLE }?.start()
    }

    private fun clock(sec: Long): String = when {
        sec < 60 -> "${sec}s"
        sec < 3600 -> "${sec / 60}m ${sec % 60}s"
        else -> "${sec / 3600}h ${(sec % 3600) / 60}m"
    }

    private var shownValue = 0.0
    private var targetValue = 0.0
    private var showPercent = false
    private val ticker = object : Runnable {
        override fun run() {
            val n = bigNumber ?: return
            shownValue += (targetValue - shownValue) * 0.16
            if (kotlin.math.abs(targetValue - shownValue) < 0.4) shownValue = targetValue
            n.text = if (showPercent) "${shownValue.toInt()}%" else num(shownValue.toInt())
            if (shownValue != targetValue) n.postOnAnimation(this)
        }
    }

    private fun applyProgress(phase: String, done: Long, total: Long, bytes: Boolean, detail: String) {
        val line = ring ?: return
        switchStage(stageOf(phase))
        val stepIdx = stepOf(phase)
        if (stepIdx >= 0) renderSteps(jobSteps[currentJob] ?: listOf(phase), stepIdx)
        val now = SystemClock.uptimeMillis()
        val elapsed = (now - jobStart) / 1000
        val stats = StringBuilder("${clock(elapsed)} elapsed")
        if (bytes && total > 0) {
            val (t0, b0) = speedSample
            if (now - t0 >= 1000 || done < b0) {
                val inst = if (done >= b0 && now > t0) (done - b0) * 1000.0 / (now - t0) else 0.0
                speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
                speedSample = Pair(now, done)
            }
            if (speed > 0) {
                stats.append("   ${fmt(speed.toLong())}/s")
                val left = ((total - done) / speed).toLong()
                if (done > 0) stats.append("   about ${clock(left)} left")
            }
        } else if (total > 0 && done > 0 && elapsed > 2) {
            val left = (elapsed * (total - done) / done)
            stats.append("   about ${clock(left)} left")
        }
        statsText?.text = stats
        if (phaseText?.text != phase) {
            phaseText?.text = phase
            if (motionOn) phaseText?.let { it.alpha = 0f; it.translationY = dpf(6); it.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(Curves.ios).start() }
        }
        detailText?.text = detail
        val wasPercent = showPercent
        if (total > 0) {
            line.indeterminate = false
            line.progress = done.toFloat() / total
            showPercent = true
            targetValue = (done * 100.0 / total).coerceAtMost(100.0)
            bigLabel?.text = if (bytes) "${fmt(done)} of ${fmt(total)}" else "${num(done.toInt())} of ${num(total.toInt())}"
        } else {
            line.indeterminate = true
            if (done > 0) { showPercent = false; targetValue = done.toDouble(); bigLabel?.text = "files found" }
            else bigLabel?.text = "one moment"
        }
        if (wasPercent != showPercent) shownValue = 0.0
        if (!motionOn) shownValue = targetValue
        bigNumber?.removeCallbacks(ticker)
        bigNumber?.postOnAnimation(ticker)
    }

    // ---------- Results ----------

    private fun showResults(r: ScanResult, motion: Motion) {
        val status = libraryStatus
        val col = column()
        col.addView(label("Scan complete", 30f, ink, 800, top = 4))
        col.addView(label("${files(r.items.size)} checked", 15f, inkDim, top = 4))

        // Headline over a mosaic of the person's own photos
        val hero = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Palette.cobalt, violet)).apply { cornerRadius = dpf(24) }
            clipToOutline = true
        }
        val mosaic = MosaicView(this, motionOn)
        if (thumbs.isNotEmpty()) mosaic.setPhotos(thumbs)
        hero.addView(mosaic, FrameLayout.LayoutParams(-1, -1))
        val heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        if (r.duplicateCount > 0) {
            heroText.addView(label(fmt(r.duplicateBytes), 52f, Color.WHITE, 800))
            heroText.addView(label("hiding in ${num(r.duplicateCount)} duplicate files", 16f, Color.parseColor("#F3E8FF")))
        } else {
            heroText.addView(label("No duplicates", 38f, Color.WHITE, 800))
            heroText.addView(label("Every file is unique.", 16f, Color.parseColor("#E3E7FF")))
        }
        hero.addView(heroText, FrameLayout.LayoutParams(-1, -1))
        col.addView(hero, LinearLayout.LayoutParams(-1, dp(220)).apply { topMargin = dp(16) })
        if (thumbs.isEmpty()) loadThumbs(r) { mosaic.setPhotos(it) }

        // Counter-check
        if (status != null) {
            val ok = status.missing.isEmpty()
            val c = card(col, if (ok) Color.parseColor("#12291F") else surface2, top = 12)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = if (ok) "✓" else "!"
                gravity = Gravity.CENTER
                textSize = 16f
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                setTextColor(bg)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (ok) mint else sunflower) }
            }, LinearLayout.LayoutParams(dp(32), dp(32)).apply { rightMargin = dp(12) })
            val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            txt.addView(label(if (ok) "Nothing missed" else "${num(status.missing.size)} files not saved yet", 16f, ink, 700))
            txt.addView(label(if (ok) "All ${num(status.saved)} files are in “${status.library.name}”" + (if (status.deep) ", checked byte by byte." else ".")
                else "${num(status.saved)} already in “${status.library.name}”. ${fmt(status.missingBytes)} to go.", 13f, inkDim, top = 2))
            row.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(row)
            if (!status.deep) c.addView(textButton("Verify byte by byte", accentText) { startVerify() }.apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; setPadding(dp(44), 0, 0, 0) })
        }

        // Types
        col.addView(label("What’s on your phone", 20f, ink, 700, top = 26))
        val types = card(col, top = 12)
        var first = true
        for (cat in Category.values()) {
            val all = r.items.filter { it.category == cat }
            if (all.isEmpty()) continue
            val dups = r.groups.sumOf { g -> g.extras.count { it.category == cat } }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(52)
                setPadding(0, if (first) 0 else dp(4), 0, 0)
            }
            first = false
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(label(cat.label, 15f, ink, 500))
            left.addView(label(files(all.size) + if (dups > 0) ", ${num(dups)} duplicates" else "", 13f, inkDim, top = 1))
            row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(fmt(all.sumOf { it.size }), 15f, ink, 500))
            types.addView(row)
        }
        // Storage now vs after cleanup
        val fs = StatFs(phoneRoot.path)
        val total = fs.totalBytes
        val used = total - fs.availableBytes
        col.addView(label("Your storage", 20f, ink, 700, top = 26))
        val sc = card(col, top = 12)
        sc.addView(StorageBars(this, motionOn).apply { this.total = total; this.used = used; reclaim = r.duplicateBytes.coerceAtMost(used) },
            LinearLayout.LayoutParams(-1, dp(110)))
        val legend = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun key(color: Int, text: String) {
            legend.addView(View(this).apply { background = rounded(color, 4) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(6) })
            legend.addView(label(text, 12f, inkDim), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(14) })
        }
        key(electric, "Used ${fmt(used)}")
        key(sunflower, "Duplicates ${fmt(r.duplicateBytes)}")
        sc.addView(legend, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        sc.addView(label("Free now ${fmt(total - used)}, after cleanup ${fmt(total - used + r.duplicateBytes.coerceAtMost(used))} of ${fmt(total)}", 13f, ink, 500, top = 8))

        // Free up space: originals that are already safe in the library
        if (status != null && status.matched.isNotEmpty()) {
            val groupOf = HashMap<Item, List<Item>>()
            r.groups.forEach { g -> groupOf[g.keep] = listOf(g.keep) + g.extras }
            val originals = status.matched.keys.flatMap { groupOf[it] ?: listOf(it) }
            val bytes = originals.sumOf { it.size }
            val fc = card(col, Color.parseColor("#1E1533"), top = 12)
            fc.addView(label("Free up ${fmt(bytes)}", 20f, ink, 800))
            fc.addView(label("${files(originals.size)} on your phone are already safe in “${status.library.name}”. Move them to Twinless Trash. Each one is checked byte by byte first, and you can undo for 30 days.", 13f, inkDim, top = 4))
            fc.addView(primary("Free up ${fmt(bytes)}") { confirmFreeUp(originals.size, bytes) }.apply {
                layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) }
            })
        }

        if (r.appFolders.isNotEmpty()) col.addView(label("WhatsApp backups and app data are left alone.", 13f, inkDim, top = 10))
        if (r.errors.isNotEmpty()) col.addView(label("${num(r.errors.size)} items couldn’t be read. They’re listed in the report.", 13f, inkDim, top = 4))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val base = status?.missing ?: r.unique
        if (base.isNotEmpty()) bar.addView(primary("Choose what to save") { prepareReview(r); showReview(Motion.FORWARD) })
        bar.addView(textButton("Scan again") { startScan() })
        setScreen(Screen.RESULTS, col, bar, motion)
    }

    private fun loadThumbs(r: ScanResult, done: (List<Bitmap>) -> Unit) {
        val picks = (r.groups.map { it.keep } + r.unique).filter { it.category == Category.PHOTOS }.distinct().take(18)
        if (picks.isEmpty()) return
        Thread {
            val out = ArrayList<Bitmap>()
            val size = dp(84)
            for (p in picks) {
                try {
                    val b = Thumbs.decode(p, size) ?: continue
                    out.add(MosaicView.rounded(b, size, dpf(12)))
                } catch (e: Exception) { /* skip unreadable */ }
            }
            if (out.isNotEmpty()) runOnUiThread { thumbs = out; done(out) }
        }.start()
    }

    // ---------- Choosing what to save ----------

    private fun folderOf(i: Item): String = i.file.parentFile?.path ?: ""
    private fun files(n: Int): String = "${num(n)} ${if (n == 1) "file" else "files"}"


    private fun prepareReview(r: ScanResult) {
        val map = HashMap<Item, List<Item>>()
        val extras = HashSet<Item>()
        r.groups.forEach { g -> map[g.keep] = listOf(g.keep) + g.extras; extras.addAll(g.extras) }
        copiesOf = map
        dupExtras = extras
        byFolder = r.items.groupBy { folderOf(it) }.mapValues { (_, v) -> v.sortedBy { it.file.name.lowercase() } }
        val status = libraryStatus
        savedContent = if (status == null) emptySet() else {
            val missing = status.missing.toHashSet()
            val s = HashSet<Item>()
            r.unique.filter { it !in missing }.forEach { k -> s.addAll(map[k] ?: listOf(k)) }
            s
        }
        if (enabledTypes.isEmpty()) enabledTypes.addAll(Category.values())
    }

    private fun isSaved(i: Item) = i in savedContent
    private fun isOn(i: Item) = i.category in enabledTypes && i.file.path !in excluded && !isSaved(i)

    /** The files that will be copied: each unique file once, taken from a copy that's still ticked. */
    private fun selection(): List<Item> {
        val r = scanResult ?: return emptyList()
        val base = libraryStatus?.missing ?: r.unique
        val out = ArrayList<Item>()
        for (item in base) {
            val pick = (copiesOf[item] ?: listOf(item)).firstOrNull { isOn(it) }
            if (pick != null) out.add(pick)
        }
        return out
    }

    private fun groupNames(dir: String): Pair<String, String> {
        val rel = dir.removePrefix(phoneRoot.path).trim('/')
        val parts = rel.split('/').filter {
            it.isNotEmpty() && it != "Android" && !it.equals("media", true) && !Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+$").matches(it)
        }
        val top = parts.firstOrNull() ?: "Main storage"
        val sub = if (parts.size <= 1) "Loose files" else parts.drop(1).joinToString(" › ")
        return top to sub
    }

    /** A small square preview: the photo itself, or a coloured badge with the file type. */
    private fun preview(item: Item?, size: Int, radius: Int): FrameLayout {
        val box = FrameLayout(this).apply {
            background = rounded(surface2, radius)
            clipToOutline = true
        }
        if (item == null) return box
        val media = item.category == Category.PHOTOS || item.category == Category.VIDEOS
        if (media) {
            val img = android.widget.ImageView(this).apply { scaleType = android.widget.ImageView.ScaleType.CENTER_CROP }
            box.addView(img, FrameLayout.LayoutParams(-1, -1))
            Thumbs.load(item, size, img)
            if (item.category == Category.VIDEOS) box.addView(label("▶", 11f, Color.WHITE, 700).apply {
                setShadowLayer(6f, 0f, 0f, Color.BLACK)
                setPadding(dp(5), dp(3), 0, 0)
            })
        } else {
            val ext = item.file.extension.uppercase(Locale.ROOT).take(4).ifEmpty { "FILE" }
            box.addView(label(ext, if (size > dp(80)) 18f else 11f, typeColor(item.category), 800).apply { gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(-1, -1))
        }
        return box
    }

    private fun typeColor(c: Category): Int = when (c) {
        Category.DOCUMENTS -> Color.parseColor("#FF7A6B")
        Category.AUDIO -> Color.parseColor("#3DDC97")
        Category.ARCHIVES -> sunflower
        Category.APPS -> Color.parseColor("#62D2FF")
        Category.OTHER -> inkDim
        else -> electric
    }

    private fun stateOf(list: List<Item>): Int {
        val selectable = list.filter { !isSaved(it) && it.category in enabledTypes }
        if (selectable.isEmpty()) return if (list.isNotEmpty() && list.all { isSaved(it) }) 3 else 0
        val on = selectable.count { it.file.path !in excluded }
        return when (on) { 0 -> 0; selectable.size -> 1; else -> 2 }
    }

    /** 0 off, 1 on, 2 partly, 3 already saved. */
    private fun styleCheck(v: TextView, state: Int) {
        v.text = when (state) { 1, 3 -> "✓"; 2 -> "–"; else -> "" }
        v.setTextColor(if (state == 3) mint else Color.WHITE)
        v.background = GradientDrawable().apply {
            cornerRadius = dpf(7)
            when (state) {
                0 -> { setColor(Color.TRANSPARENT); setStroke(dp(2), Palette.line) }
                1 -> setColor(electric)
                2 -> setColor(Palette.withAlpha(electric, 140))
                else -> setColor(Palette.withAlpha(mint, 60))
            }
        }
    }

    /** A tick box for a whole folder or group; reads the live state when tapped. */
    private fun groupCheck(list: () -> List<Item>, after: () -> Unit): TextView = checkBox(0).apply {
        styleCheck(this, stateOf(list()))
        setOnClickListener {
            val all = list()
            val st = stateOf(all)
            if (st != 3) { setAll(all.filter { !isSaved(it) }, st != 1); after() }
        }
    }

    private fun setAll(list: List<Item>, on: Boolean) {
        for (i in list) { if (on) excluded.remove(i.file.path) else excluded.add(i.file.path) }
    }

    /** One file as a square tile: tap to tick, hold to preview. Repaints itself in place. */
    private fun fileTile(item: Item, sizePx: Int, onChanged: () -> Unit): SquareFrame {
        val cell = SquareFrame(this)
        cell.background = rounded(surface2, 8)
        cell.clipToOutline = true
        val pv = preview(item, sizePx, 8)
        cell.addView(pv, FrameLayout.LayoutParams(-1, -1))
        if (item.category != Category.PHOTOS && item.category != Category.VIDEOS) {
            cell.addView(label(item.file.name, 10f, inkDim).apply {
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                setPadding(dp(6), 0, dp(6), dp(6))
            }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }
        val saved = isSaved(item)
        val tag = when {
            saved -> "Saved" to mint
            item in dupExtras -> "Copy" to sunflower
            else -> null
        }
        if (tag != null) cell.addView(label(tag.first, 9f, bg, 700).apply {
            background = rounded(tag.second, 7)
            setPadding(dp(5), dp(1), dp(5), dp(1))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(4), 0, 0, dp(4)) })
        val tick = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 11f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        if (!saved) cell.addView(tick, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(5), dp(5), 0) })

        fun paint() {
            val on = isOn(item)
            pv.alpha = if (on || saved) 1f else 0.35f
            cell.alpha = if (item.category !in enabledTypes && !saved) 0.5f else 1f
            tick.text = if (on) "✓" else ""
            tick.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (on) setColor(electric) else { setColor(Color.argb(90, 0, 0, 0)); setStroke(dp(2), Color.WHITE) }
            }
            cell.foreground = if (on && !saved) GradientDrawable().apply { cornerRadius = dpf(8); setStroke(dp(2), electric) } else null
        }
        paint()
        cell.setOnClickListener {
            when {
                saved -> Toast.makeText(this, "Already in your library", Toast.LENGTH_SHORT).show()
                item.category !in enabledTypes -> Toast.makeText(this, "${item.category.folder} are switched off above", Toast.LENGTH_SHORT).show()
                else -> {
                    if (item.file.path in excluded) excluded.remove(item.file.path) else excluded.add(item.file.path)
                    paint()
                    if (motionOn) cell.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).withEndAction {
                        cell.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(Curves.pop).start()
                    }.start()
                    onChanged()
                }
            }
        }
        cell.setOnLongClickListener { showPreview(item); true }
        return cell
    }

    /** The files of one folder, shown right under it as a grid, a page at a time. */
    private fun inlineFiles(path: String, items: List<Item>, rerender: () -> Unit, onChanged: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(2), dp(10), dp(10)) }
        val cols = 4
        val limit = shownCount[path] ?: 40
        val tile = (resources.displayMetrics.widthPixels - dp(80)) / cols
        for (rowItems in items.take(limit).chunked(cols)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until cols) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                if (i < rowItems.size) row.addView(fileTile(rowItems[i], tile, onChanged), lp) else row.addView(View(this), lp)
            }
            box.addView(row)
            if (motionOn) { row.alpha = 0f; row.animate().alpha(1f).setDuration(320).setInterpolator(Curves.ios).start() }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (items.size > limit) {
            val more = minOf(80, items.size - limit)
            actions.addView(textButton("Show $more more", electric) { shownCount[path] = limit + more; rerender() })
        }
        actions.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        if (items.size > 40) actions.addView(textButton("Full screen", inkDim) { showFolder(path, Motion.FORWARD) })
        box.addView(actions)
        return box
    }

    private fun showReview(motion: Motion) {
        val r = scanResult ?: return
        val col = column()
        col.addView(textButton("‹  Results", ink) { showResults(r, Motion.BACK) }.apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, 0) })
        col.addView(label("Choose what to save", 30f, ink, 800, top = 2))
        col.addView(label("Tap a folder to see its files. Tap a file to tick or untick it.", 15f, inkDim, top = 4))

        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipScroll.addView(chips)
        col.addView(chipScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        col.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)

        val summary = label("", 14f, inkDim, center = true)
        val saveBtn = primary("Save") {}
        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bar.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        bar.addView(saveBtn)

        val groups = byFolder.keys.groupBy { groupNames(it).first }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
        val refreshers = ArrayList<() -> Unit>()

        fun updateSummary() {
            val sel = selection()
            summary.text = if (sel.isEmpty()) "Nothing ticked" else "${files(sel.size)}, ${fmt(sel.sumOf { it.size })}"
            saveBtn.text = if (sel.isEmpty()) "Tick something to save" else "Save ${files(sel.size)}"
            saveBtn.alpha = if (sel.isEmpty()) 0.45f else 1f
            saveBtn.setOnClickListener { if (sel.isNotEmpty()) askWhereToSave(sel) }
        }
        val light: () -> Unit = { refreshers.forEach { it() }; updateSummary() }

        lateinit var render: () -> Unit

        /** A folder row whose files drop down under it. */
        fun folderBlock(section: LinearLayout, path: String, title: String, indent: Int, big: Boolean) {
            val items = byFolder[path].orEmpty()
            val isOpen = path in openFiles
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(if (big) 68 else 60)
                setPadding(dp(indent), dp(8), dp(14), dp(8))
                isClickable = true
                setOnClickListener {
                    if (isOpen) openFiles.remove(path) else openFiles.add(path)
                    render()
                }
            }
            val thumb = if (big) 48 else 40
            row.addView(preview(items.firstOrNull { it.category == Category.PHOTOS } ?: items.firstOrNull(), dp(thumb), 12),
                LinearLayout.LayoutParams(dp(thumb), dp(thumb)).apply { rightMargin = dp(12) })
            val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            txt.addView(label(title, if (big) 16f else 15f, ink, if (big) 700 else 500).apply { maxLines = 2 })
            val sub = label("", 12f, inkDim, top = 1)
            txt.addView(sub)
            row.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            val check = groupCheck({ byFolder[path].orEmpty() }) { light() ; if (path in openFiles) render() }
            row.addView(check)
            val chev = label("›", 20f, inkDim).apply {
                setPadding(dp(12), 0, dp(2), dp(2))
                rotation = if (isOpen) 90f else 0f
            }
            row.addView(chev)
            section.addView(row)
            val dups = items.count { it in dupExtras }
            val refresh = {
                val on = items.count { isOn(it) }
                sub.text = "${num(on)} of ${files(items.size)} ticked, ${fmt(items.sumOf { it.size })}" + if (dups > 0) ", ${num(dups)} copies" else ""
                styleCheck(check, stateOf(items))
            }
            refresh()
            refreshers.add(refresh)
            if (isOpen) section.addView(inlineFiles(path, items, render, light))
        }

        render = {
            refreshers.clear()
            chips.removeAllViews()
            for (cat in Category.values()) {
                if (r.items.none { it.category == cat }) continue
                val on = cat in enabledTypes
                chips.addView(TextView(this).apply {
                    text = if (on) "✓  ${cat.folder}" else cat.folder
                    textSize = 13f
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    setTextColor(if (on) Color.WHITE else inkDim)
                    gravity = Gravity.CENTER
                    setPadding(dp(14), 0, dp(14), 0)
                    background = GradientDrawable().apply {
                        cornerRadius = dpf(16)
                        if (on) setColor(Palette.withAlpha(electric, 210)) else { setColor(Color.TRANSPARENT); setStroke(dp(1), Palette.line) }
                    }
                    setOnClickListener { if (on) enabledTypes.remove(cat) else enabledTypes.add(cat); render() }
                }, LinearLayout.LayoutParams(-2, dp(34)).apply { rightMargin = dp(8) })
            }

            tools.removeAllViews()
            tools.addView(label("${num(byFolder.size)} folders", 13f, inkDim), LinearLayout.LayoutParams(0, -2, 1f))
            tools.addView(textButton("Select all", electric) { excluded.clear(); enabledTypes.addAll(Category.values()); render() })
            tools.addView(textButton("None", electric) { r.items.forEach { excluded.add(it.file.path) }; render() })

            list.removeAllViews()
            for ((name, folders) in groups) {
                val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(20) }
                if (folders.size == 1) {
                    folderBlock(section, folders[0], name, 12, true)
                } else {
                    val all = folders.flatMap { byFolder[it].orEmpty() }
                    val isOpen = name in expanded
                    val head = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        minimumHeight = dp(68)
                        setPadding(dp(12), dp(10), dp(14), dp(10))
                        isClickable = true
                        setOnClickListener { if (isOpen) expanded.remove(name) else expanded.add(name); render() }
                    }
                    head.addView(preview(all.firstOrNull { it.category == Category.PHOTOS } ?: all.firstOrNull(), dp(48), 12),
                        LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
                    val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    txt.addView(label(name, 16f, ink, 700).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                    val dups = all.count { it in dupExtras }
                    txt.addView(label("${files(all.size)}, ${fmt(all.sumOf { it.size })}" + (if (dups > 0) ", ${num(dups)} copies" else ""), 13f, inkDim, top = 1))
                    txt.addView(label((if (isOpen) "▾ " else "▸ ") + "${folders.size} folders", 13f, electric, 500, top = 2))
                    head.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
                    val check = groupCheck({ all }) { render() }
                    head.addView(check)
                    refreshers.add { styleCheck(check, stateOf(all)) }
                    section.addView(head)
                    if (isOpen) {
                        for (f in folders.sortedBy { groupNames(it).second.lowercase() }) folderBlock(section, f, groupNames(f).second, 24, false)
                        section.setPadding(0, 0, 0, dp(8))
                    }
                }
                list.addView(section, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            }
            updateSummary()
        }
        render()
        setScreen(Screen.REVIEW, col, bar, motion)
    }

    /** Every file in one folder, full screen. */
    private fun showFolder(path: String, motion: Motion) {
        val items = byFolder[path].orEmpty()
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(8)) }
        head.addView(textButton("‹  All folders", ink) { showReview(Motion.BACK) }.apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, 0) })
        val (top, sub) = groupNames(path)
        head.addView(label(if (sub == "Loose files") top else sub, 26f, ink, 800, top = 2).apply { maxLines = 2 })
        val count = label("", 14f, inkDim, top = 4)
        head.addView(count)
        head.addView(label("Tap to tick or untick. Hold to preview.", 12f, inkDim, top = 4))
        page.addView(head)

        val grid = android.widget.GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(3)
            verticalSpacing = dp(3)
            stretchMode = android.widget.GridView.STRETCH_COLUMN_WIDTH
            setPadding(dp(12), dp(4), dp(12), dp(140))
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        val summary = label("", 14f, inkDim, center = true)
        fun refresh() {
            val on = items.count { isOn(it) }
            val saved = items.count { isSaved(it) }
            count.text = "${num(on)} of ${files(items.size)} ticked" + (if (saved > 0) ", ${num(saved)} already saved" else "")
            summary.text = "Whole selection: ${files(selection().size)}"
        }
        val tile = (resources.displayMetrics.widthPixels - dp(30)) / 3
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = fileTile(items[position], tile) { refresh() }
        }
        grid.adapter = adapter

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pair = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        bar.addView(pair)
        fun pill(text: String, action: () -> Unit) = TextView(this).apply {
            this.text = text; textSize = 15f; gravity = Gravity.CENTER; setTextColor(ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = rounded(surface2, 24)
            press(this, action)
        }
        pair.addView(pill("Tick all") { setAll(items.filter { !isSaved(it) }, true); refresh(); adapter.notifyDataSetChanged() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        pair.addView(pill("Untick all") { setAll(items, false); refresh(); adapter.notifyDataSetChanged() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        pair.addView(primary("Done") { showReview(Motion.BACK) }, LinearLayout.LayoutParams(0, dp(48), 1.2f))
        refresh()
        setScreen(Screen.FOLDER, page, bar, motion, scroll = false)
    }

    private fun showPreview(item: Item) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), 0) }
        if (item.category == Category.PHOTOS || item.category == Category.VIDEOS) {
            val img = android.widget.ImageView(this).apply { scaleType = android.widget.ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true }
            box.addView(img, LinearLayout.LayoutParams(-1, dp(320)))
            Thumbs.load(item, dp(320), img)
        }
        box.addView(label(item.file.name, 15f, ink, 600, top = 10))
        box.addView(label("${fmt(item.size)}\n${item.file.parent}", 13f, inkDim, top = 4))
        val copies = (copiesOf[item] ?: copiesOf.entries.firstOrNull { e -> item in e.value }?.value).orEmpty()
        if (copies.size > 1) box.addView(label("Same file also in:\n" + copies.filter { it != item }.joinToString("\n") { "• " + (it.file.parent ?: "") }, 13f, sunflower, top = 10))
        AlertDialog.Builder(this).setView(box).setPositiveButton("Close", null).show()
    }

    // ---------- Done ----------

    private fun showDone(r: ScanResult, c: CopyResult, status: LibraryStatus?, out: File, cancelled: Boolean, chosen: Int) {
        val missingOfChosen = c.failed.size
        val complete = !cancelled && !c.stoppedForSpace && missingOfChosen == 0 && r.errors.isEmpty()
        val col = column(Gravity.CENTER_HORIZONTAL)
        col.addView(View(this), LinearLayout.LayoutParams(1, dp(40)))
        val badge = TextView(this).apply {
            text = if (complete) "✓" else "!"
            textSize = 46f
            setTextColor(bg)
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (complete) mint else sunflower) }
        }
        col.addView(badge, LinearLayout.LayoutParams(dp(96), dp(96)))
        if (motionOn) {
            badge.scaleX = 0.6f; badge.scaleY = 0.6f; badge.alpha = 0f
            badge.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(150).setDuration(380).setInterpolator(DecelerateInterpolator(2f)).start()
        }
        col.addView(label(if (complete) "All saved" else "Not finished", 30f, ink, 800, top = 20, center = true))
        col.addView(label("${num(c.copied.size + c.alreadyThere)} of ${num(chosen)} files saved and checked.", 15f, inkDim, top = 6, center = true))

        val info = card(col, top = 24)
        fun line(k: String, v: String, top: Int) {
            info.addView(label(k, 13f, inkDim, top = top))
            info.addView(label(v, 15f, ink, 500, top = 2))
        }
        line("Folder", out.path, 0)
        if (status != null) line("Counter-check", if (status.missing.isEmpty()) "Every unique file is in the library" else "${num(status.missing.size)} unique files not in the library (unticked or not copied)", 12)
        line("Report", Engine.REPORT_NAME, 12)

        val next = card(col, if (complete) surface else Color.parseColor("#2A2412"))
        if (complete) {
            next.addView(label("Before deleting", 15f, ink, 700))
            next.addView(label("1. Look through the folder.\n2. Delete old folders, but keep WhatsApp Databases and Backups.\n3. Empty Recently deleted.", 14f, inkDim, top = 6))
        } else {
            next.addView(label("Don’t delete anything yet", 15f, sunflower, 700))
            next.addView(label(when {
                c.stoppedForSpace -> "Storage is full. Free space or use a USB drive, then scan again."
                cancelled -> "Copy was stopped. Scan again to finish."
                else -> "${num(c.failed.size + r.errors.size)} items couldn’t be copied. See the report."
            }, 14f, Color.parseColor("#D9CFA8"), top = 6))
        }
        setScreen(Screen.DONE, col, primary("Done") { scanResult = null; libraryStatus = null; showStart(Motion.BACK) }, Motion.RISE)
    }

    // ---------- Twinless Trash ----------

    private fun loadTrashCard(into: LinearLayout) {
        Thread {
            Trash.expire(phoneRoot)
            val batches = Trash.batches(phoneRoot)
            if (batches.isEmpty()) return@Thread
            ui {
                if (screen != Screen.START) return@ui
                val bytes = batches.sumOf { it.bytes }
                val n = batches.sumOf { it.files }
                val oldest = batches.minOf { it.created }
                val c = card(into, Color.parseColor("#1E1533"), top = 12)
                c.addView(label("Twinless Trash: ${fmt(bytes)}", 16f, ink, 700))
                val date = java.text.SimpleDateFormat("d MMM", Locale.ENGLISH).format(java.util.Date(oldest + Trash.DAYS * 24L * 3600 * 1000))
                c.addView(label("${files(n)} waiting. Empties itself from $date. Empty it now to get the space back.", 13f, inkDim, top = 2))
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(textButton("Put back", ink) { confirmRestore(batches) }, LinearLayout.LayoutParams(0, dp(44), 1f))
                row.addView(textButton("Empty now", violet) { confirmEmpty(batches, bytes) }, LinearLayout.LayoutParams(0, dp(44), 1f))
                c.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
                if (motionOn) { c.alpha = 0f; c.translationY = dpf(12); c.animate().alpha(1f).translationY(0f).setDuration(420).setInterpolator(Curves.ios).start() }
            }
        }.start()
    }

    private fun confirmRestore(batches: List<TrashBatch>) {
        AlertDialog.Builder(this)
            .setTitle("Put everything back?")
            .setMessage("${files(batches.sumOf { it.files })} go back to exactly where they were.")
            .setPositiveButton("Put back") { _, _ ->
                val ctx = applicationContext
                Thread {
                    var n = 0
                    val paths = ArrayList<String>()
                    for (b in batches) { paths.addAll(Trash.originals(b.dir)); n += Trash.restore(b.dir) }
                    paths.chunked(200).forEach { MediaScannerConnection.scanFile(ctx, it.toTypedArray(), null, null) }
                    ui { Toast.makeText(this, "${files(n)} put back", Toast.LENGTH_SHORT).show(); showStart(Motion.FADE) }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmEmpty(batches: List<TrashBatch>, bytes: Long) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${fmt(bytes)} permanently?")
            .setMessage("These originals are already safe in your library. This can’t be undone.")
            .setPositiveButton("Yes, delete permanently") { _, _ ->
                Thread {
                    var freed = 0L
                    for (b in batches) freed += Trash.empty(b.dir)
                    ui { Toast.makeText(this, "${fmt(freed)} freed", Toast.LENGTH_LONG).show(); showStart(Motion.FADE) }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmFreeUp(n: Int, bytes: Long) {
        AlertDialog.Builder(this)
            .setTitle("Move ${files(n)} to Twinless Trash?")
            .setMessage("Each file is checked byte by byte against its library copy first. Anything that doesn’t match stays where it is.\n\nYou can put them back for 30 days. Photos moved from WhatsApp won’t show in those chats any more.")
            .setPositiveButton("Move ${fmt(bytes)}") { _, _ -> startFreeUp() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startFreeUp() {
        val r = scanResult ?: return
        val status = libraryStatus ?: return
        if (busy) return
        busy = true
        cancelRequested = false
        currentJob = "free"
        keepScreenOn(true)
        val ctx = applicationContext
        WorkService.clearDone(ctx)
        WorkService.begin(ctx, "Freeing up space")
        showProgressScreen("Checking originals")
        Thread {
            try {
                val res = Trash.freeUp(phoneRoot, r, status, { cancelRequested }, progress)
                res.batch?.let { b -> Trash.originals(b).chunked(200).forEach { MediaScannerConnection.scanFile(ctx, it.toTypedArray(), null, null) } }
                WorkService.end(ctx, "Moved to Twinless Trash", "${String.format(Locale.US, "%,d", res.moved)} files, ${Formatter.formatFileSize(ctx, res.bytes)}. Empty the trash to get the space back.")
                ui { busy = false; keepScreenOn(false); scanResult = null; libraryStatus = null; showFreed(res) }
            } catch (e: Exception) {
                WorkService.end(ctx, "Freeing up stopped", e.message)
                ui { busy = false; keepScreenOn(false); showResults(r, Motion.FADE); alert("Freeing up stopped", e.message ?: e.toString()) }
            }
        }.start()
    }

    private fun showFreed(res: FreeResult) {
        val col = column(Gravity.CENTER_HORIZONTAL)
        col.addView(View(this), LinearLayout.LayoutParams(1, dp(36)))
        col.addView(TextView(this).apply {
            text = "✓"; textSize = 46f; setTextColor(bg); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(mint) }
            if (motionOn) { scaleX = 0.5f; scaleY = 0.5f; animate().scaleX(1f).scaleY(1f).setStartDelay(160).setDuration(520).setInterpolator(Curves.pop).start() }
        }, LinearLayout.LayoutParams(dp(96), dp(96)))
        col.addView(label("${fmt(res.bytes)} ready to free", 30f, ink, 800, top = 20, center = true))
        col.addView(label("${files(res.moved)} moved to Twinless Trash. Empty it to get the space back now, or it empties itself in ${Trash.DAYS} days.", 15f, inkDim, top = 6, center = true))
        if (res.skipped.isNotEmpty()) col.addView(label("${files(res.skipped.size)} didn’t match their library copy and were left in place.", 13f, sunflower, top = 12, center = true))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val batch = res.batch
        if (batch != null) {
            bar.addView(primary("Empty trash now") {
                confirmEmpty(listOf(TrashBatch(batch, 0, res.moved, res.bytes)), res.bytes)
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(textButton("Undo", ink) { confirmRestore(listOf(TrashBatch(batch, 0, res.moved, res.bytes))) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(textButton("Later", inkDim) { showStart(Motion.BACK) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            bar.addView(row)
        } else bar.addView(primary("Done") { showStart(Motion.BACK) })
        setScreen(Screen.DONE, col, bar, Motion.RISE)
    }

    // ---------- Actions ----------

    private val prefs get() = getSharedPreferences("onefold", MODE_PRIVATE)

    private fun knownLibraries(): List<File> =
        prefs.getStringSet("libraries", emptySet()).orEmpty().map { File(it) }.filter { it.exists() }

    private fun rememberLibrary(dir: File) {
        val set = HashSet(prefs.getStringSet("libraries", emptySet()).orEmpty())
        set.add(dir.path)
        prefs.edit().putStringSet("libraries", set).putString("last", dir.path).apply()
    }

    private fun chooseLibrary(found: List<File>): File? {
        if (found.isEmpty()) return null
        val last = prefs.getString("last", null)
        return found.firstOrNull { it.path == last } ?: found.maxByOrNull { it.lastModified() }
    }

    private fun startScan() {
        if (busy) return
        busy = true
        cancelRequested = false
        scanResult = null
        libraryStatus = null
        thumbs = emptyList()
        excluded.clear(); enabledTypes.clear(); expanded.clear(); openFiles.clear(); shownCount.clear()
        currentJob = "scan"
        keepScreenOn(true)
        askForNotifications()
        val ctx = applicationContext
        WorkService.clearDone(ctx)
        WorkService.begin(ctx, "Scanning your phone")
        showProgressScreen("Looking for files")
        Thread {
            try {
                val r = Engine.scan(phoneRoot, knownLibraries(), HashCache(File(ctx.filesDir, "hashes.tsv")), { cancelRequested }, progress)
                val lib = chooseLibrary(r.librariesFound)
                val status = if (lib != null) Engine.checkLibrary(r, lib, false, { cancelRequested }, progress) else null
                WorkService.end(ctx, "Scan complete", if (r.duplicateCount > 0) "${Formatter.formatFileSize(ctx, r.duplicateBytes)} in ${String.format(Locale.US, "%,d", r.duplicateCount)} duplicate files" else "No duplicates found")
                ui { busy = false; keepScreenOn(false); scanResult = r; libraryStatus = status; showResults(r, Motion.RISE) }
            } catch (e: CancelledException) {
                WorkService.end(ctx, null, null)
                ui { busy = false; keepScreenOn(false); showStart(Motion.FADE) }
            } catch (e: Exception) {
                WorkService.end(ctx, "Scan stopped", e.message)
                ui { busy = false; keepScreenOn(false); showStart(Motion.FADE); alert("Scan stopped", e.message ?: e.toString()) }
            }
        }.start()
    }

    private fun startVerify() {
        val r = scanResult ?: return
        val lib = libraryStatus?.library ?: return
        if (busy) return
        busy = true
        cancelRequested = false
        keepScreenOn(true)
        val ctx = applicationContext
        currentJob = "verify"
        WorkService.begin(ctx, "Verifying your library")
        showProgressScreen("Verifying byte by byte")
        Thread {
            try {
                val status = Engine.checkLibrary(r, lib, true, { cancelRequested }, progress)
                WorkService.end(ctx, "Check complete", if (status.missing.isEmpty()) "Nothing missed. Every file matches." else "${status.missing.size} files not in the library")
                ui { busy = false; keepScreenOn(false); libraryStatus = status; showResults(r, Motion.FADE) }
            } catch (e: CancelledException) {
                WorkService.end(ctx, null, null)
                ui { busy = false; keepScreenOn(false); showResults(r, Motion.FADE) }
            } catch (e: Exception) {
                WorkService.end(ctx, "Check stopped", e.message)
                ui { busy = false; keepScreenOn(false); showResults(r, Motion.FADE); alert("Check stopped", e.message ?: e.toString()) }
            }
        }.start()
    }

    private fun askWhereToSave(files: List<Item>) {
        libraryStatus?.library?.let { lib ->
            if (lib.parentFile != null && folderName == Engine.OUTPUT_NAME && saveParent == Environment.getExternalStorageDirectory()) {
                saveParent = lib.parentFile!!
                folderName = lib.name
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        box.addView(label("Folder name", 13f, inkDim))
        val nameInput = EditText(this).apply {
            setText(folderName)
            setSelection(text.length)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        box.addView(nameInput)
        box.addView(label("Inside", 13f, inkDim, top = 12))
        box.addView(label(saveParent.path, 15f, ink, top = 2))
        box.addView(label("Sort into", 13f, inkDim, top = 14))
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(surface2, 18); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        val opts = listOf(Layout.ALBUM to "Album", Layout.DATE to "Date", Layout.ALBUM_DATE to "Album + year")
        val segViews = ArrayList<TextView>()
        fun paintSeg() = segViews.forEachIndexed { i, v ->
            val on = opts[i].first == layout
            v.background = if (on) rounded(electric, 15) else null
            v.setTextColor(if (on) Color.WHITE else inkDim)
        }
        for ((value, name) in opts) {
            val v = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setOnClickListener { MainActivity.layout = value; paintSeg() }
            }
            segViews.add(v)
            seg.addView(v, LinearLayout.LayoutParams(0, dp(34), 1f))
        }
        paintSeg()
        box.addView(seg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        AlertDialog.Builder(this)
            .setTitle("Save ${num(files.size)} files")
            .setView(box)
            .setPositiveButton("Save here") { _, _ ->
                val clean = nameInput.text.toString().replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                folderName = clean.ifEmpty { Engine.OUTPUT_NAME }
                startCopy(files, File(saveParent, folderName))
            }
            .setNeutralButton("Other place") { _, _ ->
                folderName = nameInput.text.toString().trim().ifEmpty { Engine.OUTPUT_NAME }
                pickFolder(saveParent) { saveParent = it; askWhereToSave(files) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startCopy(files: List<Item>, out: File) {
        val r = scanResult ?: return
        if (busy) return
        busy = true
        cancelRequested = false
        keepScreenOn(true)
        val ctx = applicationContext
        WorkService.clearDone(ctx)
        currentJob = "copy"
        WorkService.begin(ctx, "Saving your files")
        showProgressScreen("Checking space")
        val chosenLayout = layout
        Thread {
            try {
                val needed = files.sumOf { it.size }
                val free = StatFs((out.parentFile ?: out).path).availableBytes
                if (free < needed + 50L * 1024 * 1024) {
                    WorkService.end(ctx, null, null)
                    ui {
                        busy = false; keepScreenOn(false); showReview(Motion.FADE)
                        alert("Not enough space", "Needs ${fmt(needed)}, only ${fmt(free)} free. Untick some folders, free up space, or choose “Other place” for a USB drive.")
                    }
                    return@Thread
                }
                val c = Engine.copyAll(files, out, chosenLayout, { cancelRequested }, progress)
                rememberLibrary(out.canonicalFile)
                Engine.writeReport(out, r, c, chosenLayout) { fmt(it) }
                c.copied.chunked(200).forEach { chunk -> MediaScannerConnection.scanFile(ctx, chunk.toTypedArray(), null, null) }
                val cancelled = cancelRequested
                cancelRequested = false
                val status = Engine.checkLibrary(r, out.canonicalFile, false, { cancelRequested }, progress)
                val ok = !cancelled && !c.stoppedForSpace && c.failed.isEmpty()
                WorkService.end(ctx, if (ok) "All saved" else "Saving stopped",
                    "${String.format(Locale.US, "%,d", c.copied.size + c.alreadyThere)} of ${String.format(Locale.US, "%,d", files.size)} files saved and checked")
                ui { busy = false; keepScreenOn(false); showDone(r, c, status, out, cancelled, files.size) }
            } catch (e: Exception) {
                WorkService.end(ctx, "Saving stopped", e.message)
                ui { busy = false; keepScreenOn(false); showReview(Motion.FADE); alert("Copying stopped", e.message ?: e.toString()) }
            }
        }.start()
    }

    private fun alert(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }

    // ---------- Location picker ----------

    private fun volumes(): List<Pair<String, File>> {
        val sm = getSystemService(StorageManager::class.java)
        return sm.storageVolumes.mapNotNull { v ->
            val dir = v.directory
            if (dir == null) null else v.getDescription(this) to dir
        }
    }

    private fun pickFolder(start: File?, onPicked: (File) -> Unit) {
        if (start == null) {
            val vols = volumes()
            AlertDialog.Builder(this)
                .setTitle("Choose storage")
                .setItems(vols.map { "${it.first}\n${it.second.path}" }.toTypedArray()) { _, which -> pickFolder(vols[which].second, onPicked) }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val isVolumeRoot = volumes().any { it.second.path == start.path }
        val subs = (start.listFiles() ?: emptyArray())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase() }
        val labels = ArrayList<String>()
        labels.add(if (isVolumeRoot) "⬆  Other storage (USB drive)" else "⬆  Up one level")
        subs.forEach { labels.add("📁  ${it.name}") }
        AlertDialog.Builder(this)
            .setTitle("Save inside\n${start.path}")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) pickFolder(if (isVolumeRoot) null else start.parentFile, onPicked)
                else pickFolder(subs[which - 1], onPicked)
            }
            .setPositiveButton("Save here") { _, _ -> onPicked(start) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        // Work and results live here, so they survive the screen being closed while work runs.
        private var saveParent: File = Environment.getExternalStorageDirectory()
        private var folderName = Engine.OUTPUT_NAME
        private var layout = Layout.ALBUM
        @Volatile private var cancelRequested = false
        @Volatile private var busy = false
        private var scanResult: ScanResult? = null
        private var libraryStatus: LibraryStatus? = null
        private var lastUiUpdate = 0L
        private var thumbs: List<Bitmap> = emptyList()
        private val enabledTypes = HashSet<Category>()
        private val expanded = HashSet<String>()
        private var copiesOf: Map<Item, List<Item>> = emptyMap()
        private var byFolder: Map<String, List<Item>> = emptyMap()
        private var dupExtras: Set<Item> = emptySet()
        private var savedContent: Set<Item> = emptySet()
        private val excluded = HashSet<String>()
        private val openFiles = HashSet<String>()
        private val shownCount = HashMap<String, Int>()
        private var lastPhase = "Working"
        private var currentJob = "scan"

        private var live: MainActivity? = null
        private var pending: (MainActivity.() -> Unit)? = null
        private var appCtx: android.content.Context? = null

        fun requestCancel() { cancelRequested = true }

        /** Runs on whichever Twinless screen is open now, or as soon as one opens. */
        private fun ui(block: MainActivity.() -> Unit) {
            val a = live
            if (a != null && !a.isDestroyed && !a.isFinishing) a.runOnUiThread { a.block() } else pending = block
        }

        private val progress = Progress { phase, done, total, bytes, detail ->
            lastPhase = phase
            val now = SystemClock.uptimeMillis()
            val ctx = appCtx
            if (ctx != null) {
                val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else 0
                val text = if (total > 0) "$pct%  ·  $detail" else if (done > 0) "${String.format(Locale.US, "%,d", done)} files found" else detail
                WorkService.update(ctx, phase, pct, total <= 0, text)
            }
            if (now - lastUiUpdate >= 80 || (total > 0 && done >= total)) {
                lastUiUpdate = now
                val a = live ?: return@Progress
                a.runOnUiThread { a.applyProgress(phase, done, total, bytes, detail) }
            }
        }
    }
}
