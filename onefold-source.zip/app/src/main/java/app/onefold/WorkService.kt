package app.onefold

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.IBinder
import android.os.SystemClock

/**
 * Keeps scans and copies running when Twinless is in the background, and shows their
 * progress as an ongoing notification that asks to be promoted to a Live Update
 * (the status-bar pill on Android 16, shown by OxygenOS as a Live Alert).
 */
class WorkService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> { MainActivity.requestCancel(); return START_NOT_STICKY }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        val n = build(this, title, "Starting…", 0, true)
        try {
            startForeground(ID_WORK, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            // The system refused to start in the foreground; work still runs while the app is open.
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        MainActivity.requestCancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        private const val CH_WORK = "work"
        private const val CH_DONE = "done"
        private const val ID_WORK = 41
        private const val ID_DONE = 42
        private const val ACTION_CANCEL = "app.onefold.CANCEL"
        private const val ACTION_STOP = "app.onefold.STOP"
        @Volatile private var title = "Twinless"
        @Volatile private var running = false
        private var lastPost = 0L

        private fun channels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_WORK) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_WORK, "Scanning and copying", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Progress while Twinless works in the background"
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                })
            }
            if (nm.getNotificationChannel(CH_DONE) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "When a scan or copy is done"
                })
            }
        }

        private fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        private fun build(ctx: Context, title: String, text: String, percent: Int, indeterminate: Boolean): Notification {
            channels(ctx)
            val cancel = PendingIntent.getService(ctx, 1, Intent(ctx, WorkService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = Notification.Builder(ctx, CH_WORK)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setProgress(100, percent, indeterminate)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setColor(Color.parseColor("#8B6CFF"))
                .setContentIntent(openApp(ctx))
                .addAction(Notification.Action.Builder(null, "Cancel", cancel).build())
                .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
            // Ask Android 16 to promote this to a Live Update (status-bar pill / OxygenOS Live Alert).
            b.extras.putBoolean("android.requestPromotedOngoing", true)
            val chip = if (indeterminate) "Scanning" else "$percent%"
            try {
                Notification.Builder::class.java.getMethod("setShortCriticalText", String::class.java).invoke(b, chip)
            } catch (e: Exception) { /* older Android: no status-bar chip */ }
            return b.build()
        }

        fun begin(ctx: Context, what: String) {
            title = what
            running = true
            lastPost = 0L
            try {
                ctx.startForegroundService(Intent(ctx, WorkService::class.java))
            } catch (e: Exception) { /* app keeps working while open */ }
        }

        fun update(ctx: Context, phase: String, percent: Int, indeterminate: Boolean, text: String) {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            if (now - lastPost < 900) return
            lastPost = now
            try {
                ctx.getSystemService(NotificationManager::class.java)
                    .notify(ID_WORK, build(ctx, phase, text, percent, indeterminate))
            } catch (e: Exception) { /* notifications not allowed */ }
        }

        fun end(ctx: Context, doneTitle: String?, doneText: String?) {
            running = false
            try { ctx.startService(Intent(ctx, WorkService::class.java).setAction(ACTION_STOP)) } catch (e: Exception) { }
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.cancel(ID_WORK)
            if (doneTitle == null) return
            channels(ctx)
            try {
                nm.notify(ID_DONE, Notification.Builder(ctx, CH_DONE)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(doneTitle)
                    .setContentText(doneText)
                    .setColor(Color.parseColor("#8B6CFF"))
                    .setAutoCancel(true)
                    .setContentIntent(openApp(ctx))
                    .build())
            } catch (e: Exception) { }
        }

        fun clearDone(ctx: Context) {
            ctx.getSystemService(NotificationManager::class.java).cancel(ID_DONE)
        }
    }
}
