package app.onefold

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private val TILE_COLORS = intArrayOf(
    Color.parseColor("#8B6CFF"), Color.parseColor("#FF5FA2"), Color.parseColor("#3DDC97"),
    Color.parseColor("#62D2FF"), Color.parseColor("#FFC845"), Color.parseColor("#FF7A6B")
)

/** "Finding duplicates": a grid of files; a lens sweeps over them and links the ones that match. */
class MatchView(context: Context, private val animated: Boolean) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val start = SystemClock.uptimeMillis()
    private val cols = 5
    private val rows = 3
    private val r = RectF()
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val t = if (animated) (SystemClock.uptimeMillis() - start) / 1000f else 0.7f
        val cycle = 1.5f
        val round = (t / cycle).toInt()
        val f = (t % cycle) / cycle
        val rnd = Random(round * 31 + 7)
        val colors = IntArray(cols * rows) { rnd.nextInt(TILE_COLORS.size) }
        // pick one colour to be the matching group this round and make sure it appears 2–3 times
        val target = rnd.nextInt(TILE_COLORS.size)
        val spots = (0 until cols * rows).shuffled(rnd).take(2 + rnd.nextInt(2))
        for (i in colors.indices) if (colors[i] == target && i !in spots) colors[i] = (target + 1) % TILE_COLORS.size
        spots.forEach { colors[it] = target }

        val gap = 10 * d
        val size = min((width - gap * (cols + 1)) / cols, (height - gap * (rows + 1)) / rows)
        val gw = cols * size + (cols - 1) * gap
        val gh = rows * size + (rows - 1) * gap
        val ox = (width - gw) / 2
        val oy = (height - gh) / 2
        val reveal = Curves.ios.getInterpolation(((f - 0.35f) / 0.4f).coerceIn(0f, 1f))
        val lensX = ox - size + (gw + size * 2) * Curves.ios.getInterpolation((f / 0.55f).coerceIn(0f, 1f))

        fun center(i: Int): Pair<Float, Float> = Pair(ox + (i % cols) * (size + gap) + size / 2, oy + (i / cols) * (size + gap) + size / 2)

        for (i in 0 until cols * rows) {
            val (cx, cy) = center(i)
            val matched = i in spots
            val near = 1f - (abs(cx - lensX) / (size * 1.6f)).coerceIn(0f, 1f)
            val s = size * (1f + 0.08f * near + if (matched) 0.06f * reveal else 0f)
            r.set(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
            val c = TILE_COLORS[colors[i]]
            val dim = if (matched) 1f else 1f - 0.55f * reveal
            p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, Palette.withAlpha(c, (220 * dim).toInt()), Palette.withAlpha(c, (80 * dim).toInt()), Shader.TileMode.CLAMP)
            canvas.drawRoundRect(r, 10 * d, 10 * d, p)
            p.shader = null
            p.color = Color.argb((70 * dim).toInt(), 255, 255, 255)
            canvas.drawRoundRect(RectF(r.left + s * 0.18f, r.bottom - s * 0.3f, r.right - s * 0.3f, r.bottom - s * 0.22f), 3 * d, 3 * d, p)
            if (matched && reveal > 0f) {
                line.color = Palette.sunflower
                line.alpha = (255 * reveal).toInt()
                line.strokeWidth = 2.2f * d
                canvas.drawRoundRect(r, 10 * d, 10 * d, line)
            }
        }
        // links between the matching files
        if (reveal > 0f) {
            line.color = Palette.sunflower
            line.strokeWidth = 2f * d
            for (k in 1 until spots.size) {
                val (ax, ay) = center(spots[k - 1])
                val (bx, by) = center(spots[k])
                path.reset()
                path.moveTo(ax, ay)
                path.quadTo((ax + bx) / 2, min(ay, by) - size * 0.6f, ax + (bx - ax) * reveal, ay + (by - ay) * reveal)
                line.alpha = (220 * reveal).toInt()
                canvas.drawPath(path, line)
            }
        }
        // the lens
        if (f < 0.6f) {
            p.shader = RadialGradient(lensX, height / 2f, size * 1.8f, Palette.withAlpha(Color.WHITE, 46), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            canvas.drawCircle(lensX, height / 2f, size * 1.8f, p)
            p.shader = null
        }
        if (animated) postInvalidateOnAnimation()
    }
}

/** "Confirming": two files compared block by block, each matching row turning green, then a check. */
class ConfirmView(context: Context, private val animated: Boolean) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
    private val start = SystemClock.uptimeMillis()
    private val r = RectF()
    private val path = Path()
    private val rowsN = 9

    override fun onDraw(canvas: Canvas) {
        val t = if (animated) (SystemClock.uptimeMillis() - start) / 1000f else 2.0f
        val cycle = 2.6f
        val f = (t % cycle) / cycle
        val rnd = Random((t / cycle).toInt() * 13 + 3)
        val cw = min(width * 0.3f, 130 * d)
        val ch = min(height * 0.82f, cw * 1.35f)
        val cy = height / 2f
        val gapX = width * 0.13f
        val lx = width / 2f - gapX / 2 - cw
        val rx = width / 2f + gapX / 2
        val top = cy - ch / 2
        val progress = (f / 0.7f).coerceIn(0f, 1f)
        val doneRows = (progress * rowsN).toInt()

        for ((x, label) in listOf(lx to "A", rx to "B")) {
            r.set(x, top, x + cw, top + ch)
            p.shader = null
            p.color = Palette.surface2
            canvas.drawRoundRect(r, 14 * d, 14 * d, p)
            text.textSize = 11 * d
            text.color = Palette.inkDim
            canvas.drawText(label, x + cw / 2, top + 18 * d, text)
        }
        val rowH = (ch - 34 * d) / rowsN
        for (i in 0 until rowsN) {
            val y = top + 28 * d + i * rowH + rowH / 2
            val ok = i < doneRows
            val active = i == doneRows && progress < 1f
            val widthF = 0.45f + rnd.nextFloat() * 0.4f
            for (x in listOf(lx, rx)) {
                p.color = when { ok -> Palette.withAlpha(Palette.mint, 200); active -> Palette.electric; else -> Palette.line }
                canvas.drawRoundRect(RectF(x + 12 * d, y - 3 * d, x + 12 * d + (cw - 24 * d) * widthF, y + 3 * d), 3 * d, 3 * d, p)
            }
            if (ok || active) {
                stroke.color = if (ok) Palette.mint else Palette.electric
                stroke.alpha = if (ok) 150 else 255
                stroke.strokeWidth = 1.4f * d
                canvas.drawLine(lx + cw + 4 * d, y, rx - 4 * d, y, stroke)
                p.color = stroke.color
                canvas.drawCircle(lx + cw + 4 * d, y, 2.4f * d, p)
                canvas.drawCircle(rx - 4 * d, y, 2.4f * d, p)
            }
        }
        // scanning cursor
        if (progress < 1f) {
            val y = top + 28 * d + progress * rowsN * rowH
            p.shader = LinearGradient(0f, y - 14 * d, 0f, y + 14 * d, intArrayOf(Color.TRANSPARENT, Palette.withAlpha(Palette.electric, 90), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            canvas.drawRect(lx - 6 * d, y - 14 * d, rx + cw + 6 * d, y + 14 * d, p)
            p.shader = null
        }
        // the verdict
        val v = ((f - 0.72f) / 0.18f).coerceIn(0f, 1f)
        if (v > 0f) {
            val pop = Curves.pop.getInterpolation(v)
            val rad = 26 * d * pop
            p.color = Palette.mint
            canvas.drawCircle(width / 2f, cy, rad, p)
            stroke.color = Palette.bg
            stroke.alpha = 255
            stroke.strokeWidth = 4f * d
            path.reset()
            path.moveTo(width / 2f - rad * 0.4f, cy)
            path.lineTo(width / 2f - rad * 0.08f, cy + rad * 0.32f)
            path.lineTo(width / 2f + rad * 0.45f, cy - rad * 0.3f)
            canvas.drawPath(path, stroke)
        }
        if (animated) postInvalidateOnAnimation()
    }
}

/** "Copying" (or moving to trash): files fly in an arc from the phone into the library or the bin. */
class CopyView(context: Context, private val animated: Boolean, private val toTrash: Boolean) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val start = SystemClock.uptimeMillis()
    private val r = RectF()
    private val path = Path()

    private fun folder(c: Canvas, cx: Float, cy: Float, w: Float, color: Int, glow: Float) {
        val h = w * 0.74f
        if (glow > 0f) {
            p.shader = RadialGradient(cx, cy, w * 1.2f, Palette.withAlpha(color, (110 * glow).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, w * 1.2f, p)
            p.shader = null
        }
        p.color = Palette.withAlpha(color, 150)
        r.set(cx - w / 2, cy - h / 2 - h * 0.12f, cx - w / 2 + w * 0.42f, cy - h / 2 + h * 0.1f)
        c.drawRoundRect(r, 5 * d, 5 * d, p)
        p.shader = LinearGradient(cx, cy - h / 2, cx, cy + h / 2, color, Palette.withAlpha(color, 170), Shader.TileMode.CLAMP)
        r.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
        c.drawRoundRect(r, 9 * d, 9 * d, p)
        p.shader = null
    }

    private fun bin(c: Canvas, cx: Float, cy: Float, w: Float, glow: Float) {
        val color = Palette.violet
        if (glow > 0f) {
            p.shader = RadialGradient(cx, cy, w * 1.2f, Palette.withAlpha(color, (110 * glow).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, w * 1.2f, p)
            p.shader = null
        }
        p.color = color
        r.set(cx - w * 0.38f, cy - w * 0.3f, cx + w * 0.38f, cy + w * 0.5f)
        c.drawRoundRect(r, 8 * d, 8 * d, p)
        r.set(cx - w * 0.48f, cy - w * 0.44f, cx + w * 0.48f, cy - w * 0.34f)
        c.drawRoundRect(r, 4 * d, 4 * d, p)
        p.color = Palette.withAlpha(Color.WHITE, 90)
        for (k in -1..1) c.drawRoundRect(RectF(cx + k * w * 0.18f - 2 * d, cy - w * 0.18f, cx + k * w * 0.18f + 2 * d, cy + w * 0.38f), 2 * d, 2 * d, p)
    }

    override fun onDraw(canvas: Canvas) {
        val t = if (animated) (SystemClock.uptimeMillis() - start) / 1000f else 0.5f
        val w = width.toFloat()
        val cy = height / 2f + 10 * d
        val fw = min(w * 0.24f, 96 * d)
        val ax = w * 0.2f
        val bx = w * 0.8f
        val flight = 1.1f
        val spacing = 0.28f
        var landedRecently = 0f
        folder(canvas, ax, cy, fw, Palette.surface2.let { Color.parseColor("#3A3360") }, 0f)

        // dashed arc path
        stroke.color = Palette.withAlpha(Palette.electric, 70)
        stroke.strokeWidth = 1.5f * d
        stroke.pathEffect = android.graphics.DashPathEffect(floatArrayOf(4 * d, 6 * d), -t * 30 * d)
        path.reset()
        path.moveTo(ax, cy - fw * 0.2f)
        path.quadTo(w / 2, cy - height * 0.42f, bx, cy - fw * 0.2f)
        canvas.drawPath(path, stroke)
        stroke.pathEffect = null

        for (k in 0 until 5) {
            val local = ((t + k * spacing) % (spacing * 5)) / flight
            if (local > 1f) {
                val since = (local - 1f) * flight
                if (since < 0.25f) landedRecently = maxOf(landedRecently, 1f - since / 0.25f)
                continue
            }
            val e = Curves.ios.getInterpolation(local)
            val x = ax + (bx - ax) * e
            val peak = cy - height * 0.42f
            val y = (1 - e) * (1 - e) * (cy - fw * 0.2f) + 2 * (1 - e) * e * peak + e * e * (cy - fw * 0.2f)
            val s = 26 * d * (1f - 0.25f * sin(e * Math.PI.toFloat()))
            r.set(x - s / 2, y - s * 0.62f, x + s / 2, y + s * 0.62f)
            val c = TILE_COLORS[k % TILE_COLORS.size]
            p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, c, Palette.withAlpha(c, 120), Shader.TileMode.CLAMP)
            canvas.save()
            canvas.rotate((e - 0.5f) * 40f, x, y)
            canvas.drawRoundRect(r, 5 * d, 5 * d, p)
            canvas.restore()
            p.shader = null
        }
        if (toTrash) bin(canvas, bx, cy, fw, landedRecently) else folder(canvas, bx, cy, fw, Palette.electric, landedRecently)
        if (!toTrash && landedRecently > 0f) {
            stroke.color = Palette.mint
            stroke.alpha = (255 * landedRecently).toInt()
            stroke.strokeWidth = 3f * d
            path.reset()
            path.moveTo(bx - fw * 0.14f, cy)
            path.lineTo(bx - fw * 0.02f, cy + fw * 0.12f)
            path.lineTo(bx + fw * 0.18f, cy - fw * 0.1f)
            canvas.drawPath(path, stroke)
        }
        if (animated) postInvalidateOnAnimation()
    }
}

/** Storage now vs after cleanup, as two bars that fill in. */
class StorageBars(context: Context, private val animated: Boolean) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13 * resources.displayMetrics.scaledDensity; color = Palette.inkDim }
    private val clip = Path()
    private val start = SystemClock.uptimeMillis()
    var total = 1L
    var used = 0L
    var reclaim = 0L

    override fun onDraw(canvas: Canvas) {
        val t = if (animated) ((SystemClock.uptimeMillis() - start) / 1100f).coerceIn(0f, 1f) else 1f
        val e = Curves.ios.getInterpolation(t)
        val w = width.toFloat()
        val bh = 18 * d
        val labels = listOf("Now", "After cleanup")
        for (row in 0..1) {
            val y = row * (bh + 34 * d) + 22 * d
            canvas.drawText(labels[row], 0f, y - 8 * d, text)
            clip.reset()
            clip.addRoundRect(RectF(0f, y, w, y + bh), bh / 2, bh / 2, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clip)
            p.shader = null
            p.color = Palette.surface2
            canvas.drawRect(0f, y, w, y + bh, p)
            val base = (if (row == 0) used - reclaim else used - reclaim).coerceAtLeast(0)
            val bw = w * base / total * e
            p.shader = LinearGradient(0f, 0f, w, 0f, Palette.electric, Palette.violet, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, y, bw, y + bh, p)
            if (row == 0) {
                p.shader = null
                p.color = Palette.sunflower
                canvas.drawRect(bw, y, bw + w * reclaim / total * e, y + bh, p)
            }
            canvas.restore()
        }
        p.shader = null
        if (animated && t < 1f) postInvalidateOnAnimation()
    }
}
