package app.onefold

import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.os.StatFs
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class Layout { ALBUM, DATE, ALBUM_DATE }

enum class Category(val folder: String, val label: String) {
    PHOTOS("Photos", "Photos"),
    VIDEOS("Videos", "Videos"),
    AUDIO("Audio", "Audio and voice notes"),
    DOCUMENTS("Documents", "Documents"),
    ARCHIVES("Archives", "Archives"),
    APPS("Apps and installers", "Apps and installers"),
    OTHER("Other files", "Other files");

    companion object {
        private val map = HashMap<String, Category>().apply {
            listOf("jpg", "jpeg", "png", "heic", "heif", "webp", "gif", "bmp", "dng", "tif", "tiff", "raw", "arw", "cr2", "nef", "svg").forEach { put(it, PHOTOS) }
            listOf("mp4", "mkv", "mov", "3gp", "webm", "avi", "m4v", "ts", "mts", "m2ts", "wmv", "flv", "mpg", "mpeg").forEach { put(it, VIDEOS) }
            listOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "flac", "amr", "wma", "mid", "midi", "3ga").forEach { put(it, AUDIO) }
            listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "html", "htm", "epub", "md", "pages", "key", "numbers", "vcf").forEach { put(it, DOCUMENTS) }
            listOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz").forEach { put(it, ARCHIVES) }
            listOf("apk", "apks", "xapk", "apkm", "exe", "msi", "dmg", "deb", "appx").forEach { put(it, APPS) }
        }
        fun of(f: File): Category = map[f.extension.lowercase(Locale.ROOT)] ?: OTHER
    }
}

class Item(val file: File, val size: Long, val album: String, val category: Category) {
    val mtime: Long = file.lastModified()
    var hash: String? = null
}

class DuplicateGroup(val keep: Item, val extras: List<Item>)

class ScanResult(
    val root: File,
    val items: List<Item>,
    val unique: List<Item>,
    val groups: List<DuplicateGroup>,
    val appFilesLeftAlone: Int,
    val appFolders: Set<String>,
    val emptyFiles: Int,
    val errors: List<String>,
    val librariesFound: List<File>
) {
    val totalBytes: Long get() = items.sumOf { it.size }
    val uniqueBytes: Long get() = unique.sumOf { it.size }
    val duplicateCount: Int get() = groups.sumOf { it.extras.size }
    val duplicateBytes: Long get() = groups.sumOf { g -> g.extras.sumOf { it.size } }
}

/** Result of comparing the unique files with a library folder. */
/** [matched] links each saved unique file to its copy in the library. */
class LibraryStatus(val library: File, val saved: Int, val missing: List<Item>, val deep: Boolean, val matched: Map<Item, File> = emptyMap()) {
    val missingBytes: Long get() = missing.sumOf { it.size }
}

class CopyResult(
    val copied: List<String>,
    val alreadyThere: Int,
    val failed: List<String>,
    val stoppedForSpace: Boolean
)

/** done/total are bytes when [bytes] is true, otherwise counts. total = 0 means not known yet. */
fun interface Progress {
    fun update(phase: String, done: Long, total: Long, bytes: Boolean, detail: String)
}

class CancelledException : Exception("Cancelled")

object Engine {

    const val OUTPUT_NAME = "Twinless Library"
    const val REPORT_NAME = "_Twinless report.txt"
    const val LEGACY_REPORT = "_Onefold report.txt"
    const val MARKER = ".onefold-library"
    private const val SPACE_MARGIN = 50L * 1024 * 1024
    private const val BUF = 1 shl 20
    private val PACKAGE_LIKE = Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+$")

    // Folders that belong to an app rather than to you. Inside them only real media and
    // documents are taken; chat databases, backups and caches are never touched.
    private val APP_ROOT_NAMES = setOf("android", "whatsapp", "whatsapp business", "telegram")
    private val APP_INTERNAL_DIRS = setOf("databases", "backups", "cache", "caches", "temp", "tmp", "logs", "crashlogs")

    // ---------- Phase 1 + 2: find every file, then exact duplicates ----------

    fun scan(root: File, extraLibraries: List<File>, cache: HashCache?, isCancelled: () -> Boolean, progress: Progress): ScanResult {
        val rootCanon = root.canonicalFile
        val items = ArrayList<Item>()
        val errors = ArrayList<String>()
        val libraries = ArrayList<File>()
        val appFolders = HashSet<String>()
        var appFiles = 0
        var empty = 0
        val visited = HashSet<String>()
        val stack = ArrayList<File>()
        stack.add(rootCanon)
        visited.add(rootCanon.path)
        var folders = 0

        while (stack.isNotEmpty()) {
            if (isCancelled()) throw CancelledException()
            val dir = stack.removeAt(stack.size - 1)
            folders++
            val inAppArea = isAppArea(rootCanon, dir)
            val children = dir.listFiles()
            if (children == null) {
                errors.add("Could not open folder: ${dir.path}")
                continue
            }
            for (f in children) {
                if (f.name.startsWith(".")) continue
                if (f.isDirectory) {
                    val c = try { f.canonicalPath } catch (e: IOException) { continue }
                    if (File(c, MARKER).exists() || File(c, REPORT_NAME).exists() || File(c, LEGACY_REPORT).exists()) { libraries.add(File(c)); continue }
                    if (c.endsWith("/Android/data") || c.endsWith("/Android/obb")) continue
                    if (inAppArea && f.name.lowercase(Locale.ROOT) in APP_INTERNAL_DIRS) {
                        appFolders.add(c)
                        continue
                    }
                    if (visited.add(c)) stack.add(File(c))
                } else if (f.isFile) {
                    val cat = Category.of(f)
                    if (inAppArea && cat == Category.OTHER) {
                        appFiles++
                        appFolders.add(dir.path)
                        continue
                    }
                    val size = f.length()
                    if (size == 0L) { empty++; continue }
                    items.add(Item(f, size, albumName(rootCanon, dir), cat))
                }
            }
            progress.update("Looking for files", items.size.toLong(), 0, false, "$folders folders searched")
        }

        // Only files whose size matches another file can be duplicates, so only those are read.
        val bySize = items.groupBy { it.size }
        val candidates = bySize.values.filter { it.size > 1 }.flatten()
        val candidateBytes = candidates.sumOf { it.size }
        var doneBytes = 0L
        val unreadable = HashSet<Item>()
        val fromCache = HashSet<Item>()
        for (p in candidates) {
            if (isCancelled()) throw CancelledException()
            val hit = cache?.get(p.file.path, p.size, p.mtime)
            if (hit != null) {
                p.hash = hit.hash
                fromCache.add(p)
                doneBytes += p.size
                progress.update("Checking for duplicates", doneBytes, candidateBytes, true, p.file.name)
                continue
            }
            try {
                p.hash = sha256(p.file) { n ->
                    doneBytes += n
                    progress.update("Checking for duplicates", doneBytes, candidateBytes, true, p.file.name)
                    if (isCancelled()) throw CancelledException()
                }
                cache?.put(p.file.path, p.size, p.mtime, p.hash!!)
            } catch (e: IOException) {
                unreadable.add(p)
                errors.add("Could not read: ${p.file.path}")
            }
        }

        val groups = ArrayList<DuplicateGroup>()
        val unique = ArrayList<Item>()
        val toConfirm = bySize.values.filter { it.size > 1 }.sumOf { l ->
            l.filter { it !in unreadable }.groupBy { it.hash!! }.values.sumOf { maxOf(0, it.size - 1) }
        }
        var confirmed = 0
        for (list in bySize.values) {
            if (list.size == 1) { unique.add(list[0]); continue }
            val byHash = list.filter { it !in unreadable }.groupBy { it.hash!! }
            for (same in byHash.values) {
                if (same.size == 1) { unique.add(same[0]); continue }
                val sorted = same.sortedWith(compareBy<Item>(
                    { if (it.file.path.contains("/DCIM/")) 0 else 1 },
                    { if (isAppArea(rootCanon, it.file.parentFile ?: it.file)) 1 else 0 },
                    { it.file.lastModified() },
                    { it.file.path.length }
                ))
                val keep = sorted[0]
                val extras = ArrayList<Item>()
                for (p in sorted.drop(1)) {
                    if (isCancelled()) throw CancelledException()
                    progress.update("Confirming duplicates", (++confirmed).toLong(), toConfirm.toLong(), false, p.file.name)
                    // Byte-by-byte confirmation: a duplicate is never decided by fingerprint alone.
                    // A pair already confirmed on an earlier scan, with neither file changed since, is reused.
                    val known = cache != null && keep in fromCache && p in fromCache &&
                        cache.get(keep.file.path, keep.size, keep.mtime)?.confirmed == true &&
                        cache.get(p.file.path, p.size, p.mtime)?.confirmed == true
                    val identical = known || try { sameBytes(keep.file, p.file) } catch (e: IOException) { false }
                    if (identical) extras.add(p) else unique.add(p)
                }
                unique.add(keep)
                if (extras.isNotEmpty()) groups.add(DuplicateGroup(keep, extras))
                if (extras.isNotEmpty()) (listOf(keep) + extras).forEach { cache?.markConfirmed(it.file.path) }
            }
        }
        unique.sortBy { it.file.path }
        if (cache != null) {
            cache.keepOnly(candidates.filter { it !in unreadable }) 
            cache.save()
        }
        extraLibraries.filter { File(it, MARKER).exists() }
            .forEach { lib -> if (libraries.none { it.path == lib.canonicalPath }) libraries.add(lib.canonicalFile) }
        return ScanResult(rootCanon, items, unique, groups, appFiles, appFolders, empty, errors, libraries)
    }

    private fun isAppArea(root: File, dir: File): Boolean {
        val rel = dir.path.removePrefix(root.path).trim('/')
        if (rel.isEmpty()) return false
        return rel.split('/').any { it.lowercase(Locale.ROOT) in APP_ROOT_NAMES }
    }

    // ---------- Counter-check: is every unique file in the library? ----------

    fun checkLibrary(scan: ScanResult, library: File, deep: Boolean, isCancelled: () -> Boolean, progress: Progress): LibraryStatus {
        val bySize = HashMap<Long, MutableList<File>>()
        val stack = ArrayList<File>()
        stack.add(library)
        while (stack.isNotEmpty()) {
            if (isCancelled()) throw CancelledException()
            val d = stack.removeAt(stack.size - 1)
            d.listFiles()?.forEach { f ->
                if (f.isDirectory) stack.add(f)
                else if (!f.name.startsWith(".") && f.name != REPORT_NAME && f.name != LEGACY_REPORT) bySize.getOrPut(f.length()) { ArrayList() }.add(f)
            }
            progress.update("Checking your library", 0, 0, false, "Reading ${library.name}")
        }

        val claimed = HashSet<String>()
        val matched = HashMap<Item, File>()
        val missing = ArrayList<Item>()
        var saved = 0
        val total = scan.unique.size.toLong()
        scan.unique.forEachIndexed { i, item ->
            if (isCancelled()) throw CancelledException()
            progress.update(if (deep) "Verifying byte by byte" else "Checking your library", i.toLong(), total, false, item.file.name)
            val base = item.file.name.substringBeforeLast('.', item.file.name)
            val candidates = bySize[item.size].orEmpty().filter {
                it.path !in claimed && (it.name == item.file.name || it.name.startsWith("$base ("))
            }
            var found: File? = null
            for (c in candidates) {
                val quickMatch = !deep && c.lastModified() == item.file.lastModified()
                val match = quickMatch || try { sameBytes(item.file, c) } catch (e: IOException) { false }
                if (match) { found = c; break }
            }
            if (found != null) { saved++; claimed.add(found.path); matched[item] = found } else missing.add(item)
        }
        return LibraryStatus(library, saved, missing, deep, matched)
    }

    // ---------- Copy the missing files, verifying each one ----------

    fun copyAll(files: List<Item>, outputRoot: File, layout: Layout, isCancelled: () -> Boolean, progress: Progress): CopyResult {
        if (!outputRoot.exists() && !outputRoot.mkdirs()) throw IOException("Could not create ${outputRoot.path}")
        File(outputRoot, MARKER).createNewFile()
        val copied = ArrayList<String>()
        val failed = ArrayList<String>()
        var already = 0
        var stoppedForSpace = false
        val totalBytes = files.sumOf { it.size }
        var doneBytes = 0L

        for (p in files) {
            if (isCancelled()) break
            val startBytes = doneBytes
            try {
                val destDir = File(outputRoot, p.category.folder + "/" + subPath(p, layout))
                if (!destDir.exists() && !destDir.mkdirs()) throw IOException("Could not create folder ${destDir.path}")
                if (StatFs(destDir.path).availableBytes < p.size + SPACE_MARGIN) { stoppedForSpace = true; break }
                val tick: (Int) -> Unit = { n ->
                    doneBytes += n
                    progress.update("Copying and verifying", doneBytes / 3, totalBytes, true, p.file.name)
                }
                val srcHash = p.hash ?: sha256(p.file, tick).also { p.hash = it }
                if (p.hash != null && doneBytes == startBytes) doneBytes += p.size
                val dest = pickDestination(destDir, safeName(p.file.name), p.size, srcHash)
                if (dest == null) { already++; doneBytes = startBytes + p.size * 3; continue }

                var ok = false
                for (attempt in 1..2) {
                    val copiedHash = copyFile(p.file, dest, tick)
                    if (copiedHash == srcHash && sha256(dest, tick) == srcHash) { ok = true; break }
                    dest.delete()
                }
                if (ok) {
                    dest.setLastModified(p.file.lastModified())
                    copied.add(dest.path)
                } else {
                    failed.add("${p.file.path} (copy did not match the original)")
                }
            } catch (e: IOException) {
                failed.add("${p.file.path} (${e.message})")
            }
            doneBytes = startBytes + p.size * 3
        }
        return CopyResult(copied, already, failed, stoppedForSpace)
    }

    /** Returns a free file name, or null if an identical copy is already there. */
    private fun pickDestination(dir: File, name: String, size: Long, hash: String): File? {
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (true) {
            val candidate = File(dir, if (n == 1) name else "$base ($n)$ext")
            if (!candidate.exists()) return candidate
            if (candidate.length() == size && sha256(candidate) == hash) return null
            n++
        }
    }

    private fun subPath(p: Item, layout: Layout): String {
        if (layout == Layout.ALBUM) return p.album
        val cal = Calendar.getInstance()
        cal.time = dateOf(p)
        val year = cal.get(Calendar.YEAR).toString()
        val month = String.format(Locale.ENGLISH, "%02d - %s", cal.get(Calendar.MONTH) + 1,
            SimpleDateFormat("MMMM", Locale.ENGLISH).format(cal.time))
        return if (layout == Layout.DATE) "$year/$month" else "${p.album}/$year"
    }

    private fun plausible(d: Date?): Date? {
        if (d == null) return null
        val year = Calendar.getInstance().apply { time = d }.get(Calendar.YEAR)
        return if (year in 1990..(Calendar.getInstance().get(Calendar.YEAR) + 1)) d else null
    }

    private fun dateOf(p: Item): Date {
        try {
            if (p.category == Category.PHOTOS) {
                val exif = ExifInterface(p.file.path)
                val raw = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: exif.getAttribute(ExifInterface.TAG_DATETIME)
                if (raw != null) {
                    val d = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.ROOT).apply { isLenient = false }.parse(raw.trim())
                    plausible(d)?.let { return it }
                }
            } else if (p.category == Category.VIDEOS) {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(p.file.path)
                    val raw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE)
                    if (raw != null && raw.length >= 15) {
                        val d = SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(raw.substring(0, 15))
                        plausible(d)?.let { return it }
                    }
                } finally {
                    mmr.release()
                }
            }
        } catch (e: Exception) {
            // No usable date inside the file; use the file's own date.
        }
        return Date(p.file.lastModified())
    }

    private fun albumName(root: File, dir: File): String {
        val rel = dir.path.removePrefix(root.path).trim('/')
        val parts = rel.split('/').filter {
            it.isNotEmpty() && it != "Android" && !it.equals("media", ignoreCase = true) && !PACKAGE_LIKE.matches(it)
        }
        val name = if (parts.isEmpty()) "Main folder" else parts.takeLast(2).joinToString(" - ")
        return safeName(name)
    }

    private fun safeName(s: String): String = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "Unnamed" }

    // ---------- File helpers ----------

    fun sha256(f: File, onBytes: ((Int) -> Unit)? = null): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { input ->
            val buf = ByteArray(BUF)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                onBytes?.invoke(n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun sameBytes(a: File, b: File): Boolean {
        if (a.length() != b.length()) return false
        FileInputStream(a).use { ia ->
            FileInputStream(b).use { ib ->
                val ba = ByteArray(BUF)
                val bb = ByteArray(BUF)
                while (true) {
                    val na = readFully(ia, ba)
                    val nb = readFully(ib, bb)
                    if (na != nb) return false
                    if (na <= 0) return true
                    for (k in 0 until na) if (ba[k] != bb[k]) return false
                }
            }
        }
    }

    private fun readFully(input: FileInputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private fun copyFile(src: File, dest: File, onBytes: (Int) -> Unit): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(src).use { input ->
            FileOutputStream(dest).use { output ->
                val buf = ByteArray(BUF)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                    output.write(buf, 0, n)
                    onBytes(n)
                }
                output.flush()
                output.fd.sync()
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------- Report ----------

    fun writeReport(outputRoot: File, scan: ScanResult, copy: CopyResult, layout: Layout, fmt: (Long) -> String): File {
        val sb = StringBuilder()
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).format(Date())
        sb.appendLine("Twinless report  ($now)")
        sb.appendLine("Scanned: ${scan.root.path}")
        sb.appendLine("Organized by: $layout")
        sb.appendLine()
        sb.appendLine("Files found: ${scan.items.size} (${fmt(scan.totalBytes)})")
        for (c in Category.values()) {
            val list = scan.items.filter { it.category == c }
            if (list.isNotEmpty()) sb.appendLine("  ${c.label}: ${list.size} (${fmt(list.sumOf { it.size })})")
        }
        sb.appendLine("Exact duplicates skipped: ${scan.duplicateCount} (${fmt(scan.duplicateBytes)})")
        sb.appendLine("Unique files: ${scan.unique.size} (${fmt(scan.uniqueBytes)})")
        sb.appendLine("Copied and verified this run: ${copy.copied.size}")
        sb.appendLine("Already in the library: ${copy.alreadyThere}")
        sb.appendLine("Failed: ${copy.failed.size}")
        if (copy.stoppedForSpace) sb.appendLine("STOPPED EARLY: not enough free space. Free some space and run again; finished copies are kept.")
        sb.appendLine()

        if (copy.failed.isNotEmpty() || scan.errors.isNotEmpty()) {
            sb.appendLine("=== NOT COPIED: do not delete these originals ===")
            copy.failed.forEach { sb.appendLine(it) }
            scan.errors.forEach { sb.appendLine(it) }
            sb.appendLine()
        }

        if (scan.appFolders.isNotEmpty()) {
            sb.appendLine("=== App folders left alone (chat backups, databases, caches) ===")
            sb.appendLine("Twinless never copies these. Don't delete them if you want the apps to keep working.")
            scan.appFolders.sorted().forEach { sb.appendLine(it) }
            sb.appendLine()
        }

        sb.appendLine("=== Duplicate groups (first file was kept) ===")
        for (g in scan.groups) {
            sb.appendLine("KEPT     ${g.keep.file.path}")
            g.extras.forEach { sb.appendLine("  same   ${it.file.path}") }
        }

        val report = File(outputRoot, REPORT_NAME)
        report.writeText(sb.toString())
        return report
    }
}
