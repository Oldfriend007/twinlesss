package app.onefold

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Environment
import android.text.format.Formatter
import java.io.File

/** Weekly background check (while charging): a quick rescan that alerts when duplicates pile up. */
class WeeklyJob : JobService() {
    @Volatile private var stopped = false

    override fun onStartJob(params: JobParameters?): Boolean {
        if (!Environment.isExternalStorageManager()) return false
        stopped = false
        Thread {
            try {
                Trash.expire(Environment.getExternalStorageDirectory())
                val r = Engine.scan(Environment.getExternalStorageDirectory(), emptyList(),
                    HashCache(File(filesDir, "hashes.tsv")), { stopped }, Progress { _, _, _, _, _ -> })
                val prefs = getSharedPreferences("onefold", MODE_PRIVATE)
                val before = prefs.getLong("weekly_dup_bytes", 0L)
                prefs.edit().putLong("weekly_dup_bytes", r.duplicateBytes).apply()
                if (r.duplicateCount > 0 && r.duplicateBytes > before + 50L * 1024 * 1024) notify(r)
                jobFinished(params, false)
            } catch (e: CancelledException) {
                // stopped by the system; it will try again
            } catch (e: Exception) {
                jobFinished(params, false)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        stopped = true
        return true
    }

    private fun notify(r: ScanResult) {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel("weekly") == null) {
            nm.createNotificationChannel(NotificationChannel("weekly", "Weekly check", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        try {
            nm.notify(43, Notification.Builder(this, "weekly")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("${Formatter.formatFileSize(this, r.duplicateBytes)} of duplicates")
                .setContentText("${r.duplicateCount} duplicate files found this week. Tap to clean up.")
                .setColor(Color.parseColor("#8B6CFF"))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build())
        } catch (e: Exception) { }
    }

    companion object {
        private const val JOB_ID = 77

        fun isOn(ctx: Context) = ctx.getSystemService(JobScheduler::class.java).getPendingJob(JOB_ID) != null

        fun set(ctx: Context, on: Boolean) {
            val js = ctx.getSystemService(JobScheduler::class.java)
            if (!on) { js.cancel(JOB_ID); return }
            js.schedule(JobInfo.Builder(JOB_ID, ComponentName(ctx, WeeklyJob::class.java))
                .setPeriodic(7L * 24 * 3600 * 1000)
                .setRequiresCharging(true)
                .setRequiresBatteryNotLow(true)
                .setPersisted(true)
                .build())
        }
    }
}
