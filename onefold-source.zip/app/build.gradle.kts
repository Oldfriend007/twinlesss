plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.onefold"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.onefold"
        minSdk = 30
        targetSdk = 35
        versionCode = 10
        versionName = "2.4"
    }

    // The signing key is never stored in this repository. GitHub Actions writes it from
    // encrypted repository secrets just before building, and nowhere else.
    val keystorePath = System.getenv("TWINLESS_KEYSTORE")
    signingConfigs {
        create("release") {
            if (keystorePath != null) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("TWINLESS_KEYSTORE_PASSWORD")
                keyAlias = "twinless"
                keyPassword = System.getenv("TWINLESS_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isDebuggable = false
            if (keystorePath != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
